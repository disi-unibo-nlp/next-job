# LLM Wiki Evaluation

This repository contains the code, prepared datasets, and scripts used to reproduce the LLM Wiki experiments. The pipeline compares:

- **LLM Wiki**: build a structured wiki / knowledge graph from source documents, then answer QA pairs using the wiki.
- **Traditional RAG**: embed source chunks with `BAAI/bge-m3`, retrieve top-k chunks from Milvus Lite, then answer with the same LLM server.

The main reproducible path is Docker + vLLM. A lighter MLX path is also included for local testing on Apple Silicon.

## Repository Layout

```text
.
├── data/
│   ├── squad_demo_data/        # Prepared SQuAD demo data
│   └── multihop_rag_data/      # Prepared MultiHop-RAG data
├── scripts/
│   ├── build.sh                # Build the Docker image
│   ├── run_local.sh            # Run Docker evaluation locally on a GPU machine
│   ├── run_docker.sh           # Docker wrapper for server / scheduler usage
│   ├── run_eval.sh             # Runs inside Docker: starts vLLM and evaluates
│   └── run_mlx_local.sh        # Optional Apple Silicon / MLX evaluation path
├── src/
│   ├── utils/                  # Dataset preparation and embedding helpers
│   ├── wiki/                   # LLM Wiki init, ingest, query, lint, evaluate
│   └── traditional/            # Milvus insertion and traditional RAG evaluation
├── Dockerfile
└── requirements.txt
```

## Data

The prepared datasets are expected to use this structure:

```text
data/<dataset_name>/
├── documents/                  # Markdown documents used as source material
├── qa_pairs.json               # Evaluation questions and ground-truth answers
├── chunks.json                 # Chunks for traditional RAG
├── chunks_with_embeddings.json # Chunks plus BGE-M3 embeddings
└── wiki/                       # Generated during evaluation, or restored from backup
```

For this repository:

- `data/squad_demo_data` is the SQuAD demo dataset.
- `data/multihop_rag_data` is the MultiHop-RAG demo dataset.

If the prepared `data/` directory is already backed up in the private GitHub section, no extra data preparation is required before running the Docker evaluation.

## Prepare the SQuAD Demo Dataset

To recreate the SQuAD demo documents and QA file from scratch:

```bash
python src/utils/prepare_squad_demo.py
```

This downloads `rajpurkar/squad_v2`, selects the first 10 unique titles from the validation set, and writes:

```text
data/squad_demo_data/documents/*.md
data/squad_demo_data/qa_pairs.json
```

The traditional RAG baseline also needs:

```text
data/squad_demo_data/chunks.json
data/squad_demo_data/chunks_with_embeddings.json
```

These files are included in the prepared backup. If regenerating them manually, extract chunks from the document markers and then generate BGE-M3 embeddings before running the RAG baseline.

## Prepare the MultiHop-RAG Dataset

To recreate the MultiHop-RAG demo data:

```bash
python src/utils/prepare_multihop_rag.py
```

This downloads `yixuantt/MultiHopRAG`, selects the top referenced documents, keeps questions whose evidence is fully contained in those documents, and writes:

```text
data/multihop_rag_data/documents/*.md
data/multihop_rag_data/chunks.json
data/multihop_rag_data/qa_pairs.json
```

Then generate chunk embeddings:

```bash
cd data
python ../src/utils/embed_chunks.py
cd ..
```

Note: `src/utils/embed_chunks.py` is currently configured for `multihop_rag_data`. If using it for another dataset, update `CHUNKS_FILE` and `OUTPUT_FILE` in that script.

## Docker Setup

Build the image:

```bash
./scripts/build.sh
```

The image is based on `vllm/vllm-openai:latest` and installs the Python dependencies from `requirements.txt`.

Requirements for the Docker path:

- Docker
- NVIDIA GPU drivers
- NVIDIA Container Toolkit
- Enough GPU memory and disk space for the selected model
- Internet access for downloading Hugging Face models, unless models are already cached

## One-Command Local GPU Evaluation

Use `scripts/run_local.sh` on a GPU machine. It builds a fresh wiki for each model, runs LLM Wiki evaluation, runs the traditional RAG baseline, and writes results to `outputs/`.

```bash
./scripts/run_local.sh all squad
```

Arguments:

```bash
./scripts/run_local.sh [1|2|3|all] [squad|multihop|all]
```

Model choices:

- `1`: `Qwen/Qwen3.5-27B`
- `2`: `Qwen/Qwen3.5-122B-A10B-GPTQ-Int4`
- `3`: `Qwen/Qwen3.5-35B-A3B-FP8`
- `all`: run all three sequentially

Dataset choices:

- `squad`: SQuAD demo dataset
- `multihop`: MultiHop-RAG demo dataset
- `all`: run both datasets sequentially

Examples:

```bash
# Run only Qwen3.5-27B on SQuAD
./scripts/run_local.sh 1 squad

# Run only Qwen3.5-122B-A10B-GPTQ-Int4 on MultiHop-RAG
./scripts/run_local.sh 2 multihop

# Run all configured models on both datasets
./scripts/run_local.sh all all
```

Logs are written to:

```text
logs/
```

Results are written to:

```text
outputs/
```

Typical output files:

```text
outputs/<model_tag>_wiki_results.json
outputs/<model_tag>_rag_results.json
outputs/<model_tag>_multihop_wiki_results.json
outputs/<model_tag>_multihop_rag_results.json
```

## Manual Server Workflow

For debugging or step-by-step reproduction, start an OpenAI-compatible model server on port `8000`, then run the pipeline scripts manually.

The Python code expects:

```text
http://localhost:8000/v1
```

and uses the model name from `LLM_MODEL`.

Example environment:

```bash
export LLM_MODEL="Qwen/Qwen3.5-27B"
export MODEL_TAG="27b"
export DATA_DIR="data/squad_demo_data"
export DATASET_TAG=""
export ENABLE_THINKING="false"
export EMBED_DEVICE="cuda"
export BERTSCORE_DEVICE="cuda"
export PYTHONPATH="$PWD/src/wiki:$PWD/src/traditional"
```

Then run:

```bash
# 1. Initialize a fresh wiki
cd src/wiki
python 00_init.py

# 2. Ingest documents into the wiki / knowledge graph
python 01_ingest.py

# 3. Evaluate the LLM Wiki method
python evaluate.py --batch-size 50

# 4. Build Milvus Lite index for traditional RAG
cd ../traditional
python 01_insert_milvus.py

# 5. Evaluate traditional RAG
python 02_rag_evaluate.py
```

To run MultiHop-RAG manually, use:

```bash
export DATA_DIR="data/multihop_rag_data"
export DATASET_TAG="_multihop"
```

and repeat the same commands.

## Server / Scheduler Usage

`scripts/run_docker.sh` is a Docker wrapper intended for server or scheduler usage. It expects the model configuration to be passed through environment variables:

```bash
export LLM_MODEL="Qwen/Qwen3.5-27B"
export MODEL_TAG="27b"
export VLLM_MODEL="$LLM_MODEL"
export NGPU=1
export MAX_MODEL_LEN=65536
export COMPANION_DEVICE="cuda"
export EVAL_DATASET="squad"
export CUDA_VISIBLE_DEVICES=0

./scripts/run_docker.sh
```

Important variables:

- `LLM_MODEL`: model name used by the evaluation code.
- `MODEL_TAG`: prefix used in output filenames.
- `VLLM_MODEL`: Hugging Face repo loaded by vLLM. Defaults to `LLM_MODEL`.
- `VLLM_TOKENIZER`: optional tokenizer repo.
- `GGUF_FILENAME`: optional GGUF filename.
- `NGPU`: tensor parallel size for vLLM.
- `MAX_MODEL_LEN`: vLLM context length.
- `COMPANION_DEVICE`: device for BGE-M3 and BERTScore, usually `cuda` or `cpu`.
- `EVAL_DATASET`: `squad`, `multihop`, or `all`.

Inside Docker, `scripts/run_eval.sh` starts vLLM, waits for `/health`, runs the selected dataset pipeline, and stops the server at the end.

## Optional Apple Silicon / MLX Path

For local testing on Apple Silicon:

```bash
pip install mlx-lm "pymilvus[milvus_lite]" FlagEmbedding rouge-score bert-score openai tqdm
./scripts/run_mlx_local.sh squad
```

This path uses `mlx_lm.server` on port `8000`. It assumes the wiki and chunk embeddings already exist, so it is mainly useful for local debugging rather than full reproduction from scratch.

## Metrics

Both methods report:

- Exact Match
- Rouge-L
- BERT-F1
- Average latency
- Average token count

The LLM Wiki evaluation additionally reports:

- answer-in-context rate
- writeback count
- graph edge growth
- batch progression

The traditional RAG evaluation additionally reports:

- retrieval recall@3

## Reproducibility Checklist

To reproduce the main results from a fresh clone:

```bash
# 1. Make sure prepared data is present
ls data/squad_demo_data/qa_pairs.json
ls data/squad_demo_data/chunks_with_embeddings.json

# 2. Build Docker image
./scripts/build.sh

# 3. Run one model on SQuAD
./scripts/run_local.sh 1 squad

# 4. Check results
ls outputs/
```

For both datasets:

```bash
./scripts/run_local.sh 1 all
```

For all configured models and both datasets:

```bash
./scripts/run_local.sh all all
```

## Files to Back Up

For a private GitHub backup, include:

- `src/`
- `scripts/`
- `Dockerfile`
- `requirements.txt`
- `README.md`
- `data/squad_demo_data/`
- `data/multihop_rag_data/`

Optional but useful:

- `outputs/` for completed result JSON files
- `logs/` for run logs
- `llm_wiki.ipynb` if notebook exploration should be preserved

Do not back up large temporary caches unless needed:

- `.cache/`
- Hugging Face model cache
- Docker build cache