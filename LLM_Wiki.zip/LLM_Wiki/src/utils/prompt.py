"""
LLM Wiki Prompt Templates
Following second-brain-skill SCHEMA.md conventions (English mode)

Ingest (two-pass):
  Pass 1 (INGEST_PROMPT): Raw document → structured JSON extraction.
  Pass 2 (RECONCILE_PROMPT): Extracted JSON + existing graph → merge/conflict detection.

Query (three LLM calls):
  Call 1 (QUERY_UNDERSTAND_PROMPT): Question → search terms + entities (semantic)
  Call 2 (QUERY_PROMPT): Context + question → short answer
  Call 3 (WRITEBACK_PROMPT): Answer + context → new facts/relationships to write back
"""

# ── Pass 1: Extract from raw document (no existing knowledge needed) ──
INGEST_PROMPT = """Extract structured information from the document below.

Document Title: {title}
Document Content:
{content}

Output a single JSON object following this example:

{{"summary": "2-3 sentence summary of the document.", "document_type": "article", "document_tags": ["energy", "geopolitics"], "key_points": ["Main takeaway 1", "Main takeaway 2", "Main takeaway 3"], "entities": [{{"name": "OPEC", "tags": ["organization", "energy"], "overview": "OPEC is a permanent intergovernmental organization created at the Baghdad Conference in 1960 to coordinate petroleum policies.", "details": "### Historical Context and Founding\\nFounded by Iran, Iraq, Kuwait, Saudi Arabia, and Venezuela. It gained significant global influence during the 1973 oil crisis.\\n### Economic Impact\\nBy regulating oil production quotas, the cartel directly influences global crude prices and energy security, as demonstrated during the 1973 embargo when prices quadrupled."}}], "concepts": [{{"name": "Oil Embargo", "tags": ["economic-policy", "geopolitics"], "overview": "An oil embargo is a economic and geopolitical restriction where nations stop exporting petroleum to target countries.", "details": "### Mechanism and Execution\\nTypically enforced by collective supply cuts from major producers to exert political pressure.\\n### Case Study: 1973 Crisis\\nThe October 1973 embargo targeted western nations supporting Israel, causing severe global inflation and weaponizing energy supplies."}}], "relationships": [{{"source_name": "OPEC", "target_name": "Oil Embargo", "description": "OPEC initiated the embargo"}}], "facts_and_data": ["OPEC was founded in 1960", "The embargo began in October 1973"]}}

RULES:
1. summary: 2-3 sentences about what this document covers. REQUIRED.
2. document_type: One word — choose from: article, paper, report, blog, news, book, interview, other. REQUIRED.
3. document_tags: 2-5 high-level topic tags for THE WHOLE DOCUMENT (lowercase, hyphenated). These describe what the document is about as a whole, distinct from per-entity tags.
4. key_points: 3-5 high-level takeaways.
5. entities: Named things (person, org, place, event, product) discussed in detail. If mentioned briefly 1-2 times, do NOT include. 
6. concepts: Abstract ideas (method, theory, pattern) explained in depth.
7. Content Fields for Entities/Concepts (MUST follow these for Markdown mapping):
   - tags: Array of 1-3 specific lowercase tags.
   - overview: A single, cohesive, high-quality paragraph that defines and summarizes the item based ON THIS DOCUMENT. Maps to the [概述段落] in template.
   - details: In-depth information organized by thematic headers (using markdown '### Subheading'). Do not use simple bullet lists; write in rich, analytical paragraphs that integrate data, dates, and logic from the text. Maps to [按主题组织的详细内容] in template.
8. relationships: 
   - Use 'source_name' and 'target_name' exactly as defined in your entities/concepts lists.
   - 'description' must be a very short phrase (max 10 words) explaining the link.
9. facts_and_data: 15-25 short sentences (max 15 words each) with HIGH ROUTING VALUE (dates, numbers, specific names) to uniquely identify this document.
10. Do NOT repeat any item. Output ONLY the JSON object. No other text."""

# ── Pass 2: Reconcile with existing knowledge (small context, no raw doc) ──
RECONCILE_PROMPT = """You are maintaining a wiki knowledge base. A new document was just processed.
Compare the NEW extracted entities/concepts with EXISTING wiki nodes and identify same-thing pairs and conflicts.

EXISTING wiki entities and concepts (id — name — overview):
{existing_nodes}

NEW extracted nodes from document "{title}":
{new_data}

Output a JSON object:
{{"merge_pairs": [{{"new_id": "id-from-NEW-data", "existing_id": "id-from-EXISTING-list", "reason": "same real-world thing"}}], "conflicts": [{{"existing_id": "id-from-EXISTING-list", "new_id": "id-from-NEW-data", "existing_overview": "what the wiki says", "new_overview": "what the new document says"}}]}}

RULES:
- merge_pairs: A NEW node and an EXISTING node refer to the same real-world thing (different spelling, abbreviation, translation, alias, casing, punctuation, etc.). Use ids EXACTLY as shown in the inputs.
- conflicts: A NEW overview factually contradicts the EXISTING overview (different dates, numbers, founders, locations, etc.). Minor wording differences are NOT conflicts.
- A pair can appear in BOTH merge_pairs and conflicts if it is the same thing AND has factual contradictions.
- Only use ids that actually appear in the inputs. Do not invent ids.
- If neither merges nor conflicts exist, use empty lists [].
- Output ONLY the JSON object. No other text."""



# ── Query Call 1: Route + Search Terms (combined single LLM call) ──
QUERY_ROUTE_PROMPT = """You are a wiki knowledge base router and search planner. Given a question and the wiki index, do TWO things:
1. Decide which wiki pages to read.
2. Generate search terms to find the answer paragraph in raw source documents.

Question: {question}

Wiki Index:
{index_content}

Existing analyses:
{analyses_list}

Output a JSON object:
{{"source_pages": ["page-id-1"], "entity_pages": ["page-id-1", "page-id-2"], "concept_pages": ["page-id"], "analysis_pages": ["page-id"], "search_terms": ["term1", "term2", "synonym1", "person_name", "place_name"]}}

RULES:
- source_pages/entity_pages/concept_pages: Pick the most relevant pages. Be generous — include 1-3 source pages and any related entities/concepts. Page IDs are shown directly inside the square brackets (e.g. "- [alan-turing](entities/alan-turing.md) — ..." → "alan-turing"). Use those IDs as-is.
- analysis_pages: Only include if an existing analysis is clearly relevant.
- If unsure which source, include ALL plausible source pages.
- search_terms (REQUIRED, never omit): 8-15 keyword terms for paragraph-level matching. Always include: the core nouns from the question, synonyms/alternative phrasings (e.g. "naval base" → "port", "harbor"), relevant entity/person/place names from the index, and any technical terms. Goal: at least one term must appear in the answer paragraph.
- Output ONLY the JSON object. No other text."""

# ── Query Call 2: Answer based on retrieved context ──
QUERY_PROMPT = """Based on the following compiled knowledge from the wiki, answer the question.
CRITICAL INSTRUCTION: Give a short, direct answer. Answer using ONLY the exact entity, name, or phrase. Do not use full sentences. If the context doesn't contain the answer, say "unanswerable".
DO NOT explain your reasoning. DO NOT show your thinking process. Output ONLY the final answer, nothing else.

Compiled Knowledge:
{context}

Question: {question}

Answer:"""

# ── Query Call 3: Writeback assessment (what new knowledge to persist) ──
WRITEBACK_PROMPT = """You just answered a question using a wiki knowledge base. Assess what new knowledge should be written back to make the wiki more useful for FUTURE questions.
The wiki's value comes from knowledge compounding: each query should leave the wiki slightly richer than before, so later queries benefit from earlier ones.

Question: {question}
Answer: {answer}
Reasoning process: {thinking}
Matched KG nodes: {matched_nodes}

Determine:
1. Are there new relationships between the matched nodes that are NOT already obvious from their names/types?
2. Did the reasoning reveal a non-trivial cross-entity insight worthy of its own wiki page?

Output a JSON object:
{{"new_edges": [{{"source_id": "existing-node-id", "target_id": "existing-node-id", "relation": "relationship-type"}}], "analysis_id": "short-descriptive-id", "analysis": "A concise synthesis (2-4 sentences). MUST be empty string if no novel insight."}}

RULES:
- new_edges: ONLY use node IDs from the matched_nodes list above. relation must be one of: related_to, part_of, caused, influenced, located_in, member_of, type_of, created, founded, occurred_in. If no meaningful NEW relationships, use empty list [].
- analysis_id and analysis: write one whenever the answer connects 2+ matched nodes in a way that could help a FUTURE question. The wiki compounds knowledge — be generous about persisting cross-document links. Only leave empty when the answer is a single isolated lookup with no inter-node relationship (e.g. "What year was X founded?" with only one matched node).
  Write an analysis when ANY of these hold:
  1. The answer connects 2 or more matched nodes (entity↔entity, entity↔concept, etc.)
  2. The answer reveals a fact about how matched nodes relate (caused, influenced, part_of, …)
  3. The reasoning would let a future query short-circuit by reading this page directly
- Do NOT invent new entities. Only connect EXISTING nodes.
- Output ONLY the JSON object."""


RAG_PROMPT = """Based on the following context, answer the question.
CRITICAL INSTRUCTION: Give a short, direct answer. Answer using ONLY the exact entity, name, or phrase. Do not use full sentences. If the context doesn't contain the answer, say "unanswerable".
DO NOT explain your reasoning. DO NOT show your thinking process. Output ONLY the final answer, nothing else.


Context:
{context}

Question: {question}
Answer:"""