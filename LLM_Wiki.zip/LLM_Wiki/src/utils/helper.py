"""
LLM Wiki — Shared Utilities

Text processing, JSON parsing, LLM client, raw document lookup,
and markdown helpers used across ingest/query/lint modules.
"""

import os
import re
import json
import glob
from pathlib import Path
import frontmatter
import json_repair
from openai import OpenAI

import transformers
transformers.logging.set_verbosity_error()

import nltk
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer
nltk.download('stopwords')

STOPWORDS = set(stopwords.words('english'))
VALID_ID = re.compile(r'^[a-z0-9][a-z0-9-]*$')
_stemmer = SnowballStemmer("english")

from src.utils.config import (
    LLM_BASE_URL, LLM_API_KEY, LLM_MODEL,
    WIKI_DIR, SOURCES_DIR, ENTITIES_DIR, CONCEPTS_DIR, ANALYSES_DIR, INDEX_FILE,
    TODAY,
)

# ══════════════════════════════════════════════════
#  IO / Filename
# ══════════════════════════════════════════════════
def sanitize_filename(name):
    """Generate SCHEMA-compliant filename: lowercase + hyphens, max 50 chars.
    This is the SINGLE canonical function for all ID generation in the project."""
    name = re.sub(r'[^a-zA-Z0-9\s-]', '', name)
    name = re.sub(r'[\s_]+', '-', name.strip()).lower()
    name = re.sub(r'-+', '-', name)
    return name[:50].rstrip('-')

def load_all_pages():
    pages = {}
    for directory in [SOURCES_DIR, ENTITIES_DIR, CONCEPTS_DIR, ANALYSES_DIR]:
        label = directory.name  # "sources" | "entities" | "concepts" | "analyses"
        if not directory.exists():
            continue
        for f in glob.glob(str(directory / "*.md")):
            filepath = Path(f)
            filename = filepath.stem
            post = frontmatter.load(filepath)
            pages[filename] = {"post": post, "dir": label, "path": filepath}
    return pages

def list_analyses():
    """List existing analysis files."""
    if not ANALYSES_DIR.exists():
        return []
    return [Path(f).stem for f in glob.glob(str(ANALYSES_DIR / "*.md"))]

def load_index():
    """Load index.md content (stripped of frontmatter)."""
    if INDEX_FILE.exists():
        post = frontmatter.load(INDEX_FILE)
        content = post.content
        return content
    return ""

def get_linked_pages(pages):
    page_links = {}
    for page_id, info in pages.items():
        content = info["post"].content
        links = extract_wikilinks(content)
        links = [sanitize_filename(l) for l in links if l != page_id]
        page_links[page_id] = links
    return page_links

def ensure_dirs():
    """Create wiki directory structure if missing."""
    for d in [WIKI_DIR, SOURCES_DIR, ENTITIES_DIR, CONCEPTS_DIR, ANALYSES_DIR]:
        os.makedirs(d, exist_ok=True)

# ══════════════════════════════════════════════════
#  LLM Client (lazy singleton)
# ══════════════════════════════════════════════════
_client = None
def _get_client():
    global _client
    if _client is None:
        _client = OpenAI(base_url=LLM_BASE_URL, api_key=LLM_API_KEY)
    return _client

def check_llm_connection():
    """Verify LLM server is reachable. Raises ConnectionError if not."""
    try:
        response = _get_client().chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=1,
            temperature=0,
            timeout=120,
        )
        return True
    except Exception as e:
        raise ConnectionError(f"    Cannot connect to LLM at {LLM_BASE_URL}: {e}")

def call_llm(prompt, max_tokens=32768, enable_thinking=False):
    """Call LLM. Returns (raw_text, total_tokens)."""
    try:
        response = _get_client().chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            temperature=0,
            timeout=1200,
            extra_body={"chat_template_kwargs": {"enable_thinking": enable_thinking}},
        )
        raw = response.choices[0].message.content.strip()
        tokens = response.usage.total_tokens if response.usage else 0
        return raw, tokens
    except Exception as e:
        print(f"    [ERROR] LLM call failed: {e}")
        return "", 0


# ══════════════════════════════════════════════════
#  JSON Parsing
# ══════════════════════════════════════════════════
def parse_json_response(text, debug=False):
    """Extract JSON from LLM output. Uses json_repair for robustness."""
    if debug:
        print(f"    [DEBUG] Output length: {len(text)} chars")
        print(f"    [DEBUG] Last 200 chars:  {text[-200:]}")

    text = re.sub(r'^```(?:json)?\s*\n?', '', text.strip())
    text = re.sub(r'\n?\s*```$', '', text.strip())
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', ' ', text)

    match = re.search(r'\{', text)
    if match:
        text = text[match.start():]

    try:
        return json_repair.loads(text)
    except Exception as e:
        print(f"    [DEBUG] JSON parse error: {e}")
        return None


# ══════════════════════════════════════════════════
#  Text Processing
# ══════════════════════════════════════════════════
def strip_thinking(text):
    """Strip Qwen thinking tags. Returns (thinking, answer)."""
    if not text:
        return "", ""

    text_str = text.strip()

    open_match = re.search(r'(<think>|Thinking\s+Process:?)', text_str, re.IGNORECASE)
    close_match = re.search(r'</think>', text_str, re.IGNORECASE)

    if open_match and close_match and open_match.start() < close_match.start():
        thinking = text_str[open_match.end():close_match.start()].strip()
        answer = text_str[close_match.end():].strip()
        return thinking, answer

    if close_match:
        thinking = text_str[:close_match.start()].strip()
        answer = text_str[close_match.end():].strip()
        return thinking, answer

    if open_match:
        return text_str.strip(), ""

    return "", text_str
    
def extract_sections(body, sections):
    """Extract the content under specific section headings in markdown text."""
    extracted = []
    for section in sections:
        head, _, rest = body.partition(section)
        if section == "## Core Content":
            body = rest 
            continue
        extracted.append(head.rstrip())
        body = rest
    return "\n\n".join(extracted)

def extract_wikilinks(content):
    """Extract all [[wikilinks]] from content."""
    return re.findall(r'\[\[([^\]|]+)(?:\|[^\]]+)?\]\]', content)

def stem_text(text):
    """Tokenize text into stemmed word set (lowercase)."""
    words = re.findall(r'[a-zA-Z0-9]+', text.lower())
    return {_stemmer.stem(w) for w in words if w not in STOPWORDS}

def paragraph_term_score(text, terms):
    """Dual scorer for global paragraph ranking.

    Returns (fuzzy_hits, exact_hits):
      - exact_hits: term appears verbatim (substring match, lowercased)
      - fuzzy_hits: term appears verbatim OR any of its word stems is present
                    in the paragraph's stem set
    Multi-word terms count as 1 fuzzy hit if ANY word stem matches (not all),
    which is much more forgiving than set-issubset and matches the tutorial
    version that produced EM 59.57%.

    Use as sort key: candidates.sort(key=lambda x: (-fuzzy, -exact)).
    """
    if not text or not terms:
        return 0, 0
    text_lower = text.lower()
    raw_words = set(re.findall(r'[a-z0-9]+', text_lower))
    stemmed_words = {_stemmer.stem(w) for w in raw_words}
    fuzzy_hits = 0
    exact_hits = 0
    for term in terms:
        t = str(term).lower().strip()
        if not t:
            continue
        if t in text_lower:
            exact_hits += 1
            fuzzy_hits += 1
            continue
        # Fall back to stem-level match: any word in the term hits the paragraph
        matched = False
        for w in re.findall(r'[a-z0-9]+', t):
            if w in STOPWORDS or len(w) <= 1:
                continue
            if _stemmer.stem(w) in stemmed_words:
                matched = True
                break
        if matched:
            fuzzy_hits += 1
    return fuzzy_hits, exact_hits


# ══════════════════════════════════════════════════
#  Markdown Utilities
# ══════════════════════════════════════════════════
def update_log(entry):
    filepath = WIKI_DIR / "log.md"
    if not filepath.exists():
        return
    
    post = frontmatter.load(filepath)
    post['updated'] = TODAY
    body = post.content
    
    post.content = entry + "\n\n" + body
    filepath.write_text(frontmatter.dumps(post), encoding="utf-8")
    
def add_cross_reference(source_page, target_page):
    """Add a [[target_page]] cross-reference to source_page's Related section."""
    for directory in [SOURCES_DIR, ENTITIES_DIR, CONCEPTS_DIR]:
        filepath = directory / f"{source_page}.md"
        if filepath.exists():
            post = frontmatter.load(filepath)
            if f"[[{target_page}]]" not in post.content:
                post["updated"] = TODAY
                if "## Related" in post.content:
                    post.content = post.content.replace(
                        "## Related\n",
                        f"## Related\n\n- [[{target_page}]] — discovered via query\n"
                    )
                else:
                    post.content += f"\n\n## Related\n\n- [[{target_page}]] — discovered via query\n"
                filepath.write_text(frontmatter.dumps(post), encoding="utf-8")
            return True
    return False

# ══════════════════════════════════════════════════
#  Knowledge Graph Utilities
# ══════════════════════════════════════════════════
def is_valid_edge(src, tgt, kg):
    """Quick guard: both IDs exist in KG, are distinct, valid format, not duplicate."""
    return (
        src and tgt
        and src != tgt
        and VALID_ID.match(src)
        and VALID_ID.match(tgt)
        and src in kg.nodes
        and tgt in kg.nodes
        and not kg.has_edge(src, tgt)
    )