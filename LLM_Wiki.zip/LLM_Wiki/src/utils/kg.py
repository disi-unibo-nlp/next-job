"""
LLM Wiki — Knowledge Graph

Unified KnowledgeGraph class used by both ingest (build from scratch)
and query (load from JSON, search, save).
"""

import json
import re
from src.utils.config import GRAPH_FILE


class KnowledgeGraph:
    """
    Dual-mode knowledge graph:
      - Build mode (ingest):  KnowledgeGraph()           → empty, add nodes/edges
      - Load mode (query):    KnowledgeGraph(graph_dict) → populated from JSON
    """

    def __init__(self, graph_dict=None):
        if graph_dict is not None:
            # Load mode: dict with "nodes" list and "edges" list
            self.nodes = {n["id"]: n for n in graph_dict.get("nodes", [])}
            self.edges = list(graph_dict.get("edges", []))
        else:
            # Build mode: start empty
            self.nodes = {}
            self.edges = []

    # ── Build methods (used by ingest) ──
    def add_node(self, node_id, name, node_type, overview, source_doc):
        if node_id in self.nodes:
            if source_doc not in self.nodes[node_id].get("sources", []):
                self.nodes[node_id].setdefault("sources", []).append(source_doc)
            if len(overview) > len(self.nodes[node_id].get("overview", "")):
                self.nodes[node_id]["overview"] = overview
        else:
            self.nodes[node_id] = {
                "id": node_id,
                "name": name,
                "node_type": node_type,
                "overview": overview,
                "sources": [source_doc],
            }

    def add_edge(self, source_id, target_id, relation, source_doc=None):
        """Add edge. In query mode (no source_doc), marks as query_writeback."""
        if source_doc is None:
            # Query writeback mode — check for duplicates first
            if self.has_edge(source_id, target_id):
                return False
            source_doc = "query_writeback"
        self.edges.append({
            "source": source_id,
            "target": target_id,
            "relation": relation,
            "source_doc": source_doc,
        })
        return True

    # ── Query methods (used by query) ──
    def search_nodes(self, query_terms):
        results = []
        query_lower = [t.lower() for t in query_terms]
        for nid, node in self.nodes.items():
            score = 0
            name_lower = node["name"].lower()
            overview_lower = node.get("overview", "").lower()
            id_lower = nid.lower()
            for term in query_lower:
                if term == name_lower or term == id_lower:
                    score += 5
                elif term in name_lower or term in id_lower:
                    score += 3
                if term in overview_lower:
                    score += 1
            if score > 0:
                results.append((nid, score))
        results.sort(key=lambda x: -x[1])
        return results

    def get_neighbors(self, node_id, depth=1):
        visited = set()
        current = {node_id}
        for _ in range(depth):
            nxt = set()
            for nid in current:
                visited.add(nid)
                for edge in self.edges:
                    if edge["source"] == nid and edge["target"] not in visited:
                        nxt.add(edge["target"])
                    elif edge["target"] == nid and edge["source"] not in visited:
                        nxt.add(edge["source"])
            current = nxt
        visited.update(current)
        visited.discard(node_id)
        return visited

    def get_edges_for_nodes(self, node_ids):
        s = set(node_ids)
        return [e for e in self.edges if e["source"] in s or e["target"] in s]

    def has_edge(self, source_id, target_id):
        """Check if an edge already exists (either direction)."""
        return any(
            (e["source"] == source_id and e["target"] == target_id) or
            (e["source"] == target_id and e["target"] == source_id)
            for e in self.edges
        )

    # ── Serialization ──
    def to_dict(self):
        return {
            "nodes": list(self.nodes.values()),
            "edges": self.edges,
            "stats": {
                "num_nodes": len(self.nodes),
                "num_edges": len(self.edges),
                "num_entities": sum(1 for n in self.nodes.values() if n["node_type"] == "entity"),
                "num_concepts": sum(1 for n in self.nodes.values() if n["node_type"] == "concept"),
            }
        }
    def save(self, path=None):
        """Save graph to JSON file."""
        out_path = path or GRAPH_FILE
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)
