"""
LLM Wiki — Shared Configuration

All path constants, LLM settings, and directory setup used across modules.
Single source of truth: change here, reflected everywhere.
"""

import os
from datetime import datetime
from pathlib import Path

# ── Paths ──
ROOT = Path(__file__).resolve().parent.parent.parent
DATA_DIR_NAME = os.environ.get("DATA_DIR", "data/squad_data")
KB_DIR = ROOT / DATA_DIR_NAME
RAW_DIR = KB_DIR / "documents"
WIKI_DIR = KB_DIR / "wiki"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

# ── Dataset Configuration ──
DATA_DOC_NUM=10
CHUNK_SIZE=300

# Wiki subdirectories
SOURCES_DIR = WIKI_DIR / "sources"
ENTITIES_DIR = WIKI_DIR / "entities"
CONCEPTS_DIR = WIKI_DIR / "concepts"
ANALYSES_DIR = WIKI_DIR / "analyses"

GRAPH_FILE = WIKI_DIR / "knowledge_graph.json"
INDEX_FILE = WIKI_DIR / "index.md"

# Evaluation files
QA_FILE = KB_DIR / "qa_pairs.json"
BATCH_SIZE = 32
NO_WRITEBACK = False

# ── LLM API (OpenAI-compatible) ──
LLM_BASE_URL = f"http://localhost:{os.environ.get('LLM_PORT', '8000')}/v1"
LLM_API_KEY = "EMPTY"
LLM_MODEL = os.environ.get("LLM_MODEL", "mlx-community/Qwen3.5-9B-MLX-4bit")
MODEL_TAG = os.environ.get("MODEL_TAG", "model")
ENABLE_THINKING = os.environ.get("ENABLE_THINKING", "false").lower() == "true"
MAX_MODEL_TOKENS = 16384

INGEST_TOKENS    = 16384
RECONCILE_TOKENS = 1024

ROUTE_TOKENS     = 1024
QUERY_TOKENS     = 8192 if ENABLE_THINKING else 1024
WRITEBACK_TOKENS = 1024
LINT_TOKENS      = 4096

# ── Date ──
TODAY = datetime.now().strftime("%Y-%m-%d")

# ── Retrieval ──
SECTION_CONFIGS = {
    "analysis": ["## Cross-Document Analysis", "## Related"],
    "entity"  : ["## Details", "## Related"],
    "concept" : ["## Details", "## Related"],
    "source"  : ["## Core Content", "## Key Points", "## Citations & Data", "## Related"],
}
TOTAL_CONTEXT_BUDGET = 16384 # in chars, not tokens, to leave room for LLM output

# ── RAG ──
EMB_MODEL_NAME = "BAAI/bge-m3"
EMB_DIM = 1024
CHUNKS_FILE = KB_DIR / "chunks_with_embeddings.json"
DB_FILE = KB_DIR / "milvus.db"
COLLECTION_NAME = "rag_chunks"
TOP_K = 3

