"""
LLM Wiki Lint — Health Check Workflow

Pipeline:
  1. Run all deterministic structural checks → P0 / P1 issues.
  2. Always auto-fix every P0 silently (orphan-source cascade + index entries).
  3. Print the full report (P0 + P1) so the user sees both what was fixed
     and what remains.
  4. --fix      → interactively prompt for each P1 issue.
     --fix --yes → silently apply the fixable P1 issues, skip the rest.

Usage:
    python -m src.wiki.lint              # auto-fix P0, report everything
    python -m src.wiki.lint --fix        # also: interactive P1 fixes
    python -m src.wiki.lint --fix --yes  # also: auto-apply fixable P1
"""
import re
import json
import argparse
import frontmatter
from pathlib import Path
from collections import Counter, defaultdict

from src.utils.config import (
    WIKI_DIR, KB_DIR, GRAPH_FILE, INDEX_FILE,
    TODAY
)
from src.utils.helper import load_all_pages, get_linked_pages, update_log, ensure_dirs
from src.utils.kg import KnowledgeGraph

# -- init
ensure_dirs()

# ══════════════════════════════════════════════════
#  P0 checks — structural integrity (must auto-fix)
# ══════════════════════════════════════════════════
def check_broken_wikilinks(pages, page_links):
    """[[link]] points to a page id that does not exist on disk."""
    issues = []
    all_ids = set(pages.keys())
    
    for page_id, _ in pages.items():
        linked_ids = page_links.get(page_id, [])
        for linked_id in linked_ids:
            if linked_id not in all_ids:
                issues.append({
                    "severity": "P0",
                    "type": "broken_link",
                    "page": page_id,
                    "detail": f"[[{linked_id}]] points to a non-existent page",
                    "fix": f"Remove the link.",
                })
    return issues

def check_index_consistency(pages):
    """Every source/entity/concept page on disk appears in index.md; every index entry resolves to disk."""
    issues = []
    if not INDEX_FILE.exists():
        issues.append({
            "severity": "P0",
            "type": "index_missing",
            "page": "index.md",
            "detail": "wiki/index.md does not exist",
            "fix": "Run `python -m src.wiki.init` to create the wiki scaffold.",
        })
        return issues

    index_content = frontmatter.load(INDEX_FILE).content
    # entries appearing in the index (markdown link pointing into sources/entities/concepts/analyses)
    entry_pattern = re.compile(r'\((sources|entities|concepts|analyses)/([^)]+?)\.md\)')
    indexed = {(m.group(1), m.group(2)) for m in entry_pattern.finditer(index_content)}

    # 1) page on disk but missing from index
    for page_id, info in pages.items():
        directory = info["dir"]
        if directory == "analyses":
            # analyses are optional in the index
            continue
        if (directory, page_id) not in indexed:
            issues.append({
                "severity": "P0",
                "type": "index_missing_entry",
                "page": page_id,
                "detail": f"`{directory}/{page_id}.md` exists on disk but is missing from index.md",
                "fix": f"Add an entry under `## {directory.capitalize()}` in index.md.",
            })

    # 2) index entry that no longer corresponds to a file
    for directory, page_id in indexed:
        if not (WIKI_DIR / f"{directory}/{page_id}.md").exists():
            issues.append({
                "severity": "P0",
                "type": "index_stale_entry",
                "page": "index.md",
                "target": f"{directory}/{page_id}.md",
                "detail": f"index.md references `{directory}/{page_id}.md` but the file does not exist",
                "fix": f"Remove the dangling entry from index.md or recreate the file.",
            })
    return issues

def check_orphan_sources(pages, page_links):
    """Source pages whose raw file in documents/ has been deleted.

    A node is "dependent" if it lists the source in its frontmatter `sources`
    OR its body wikilinks to the source (the two signals are unioned, so a
    node with a broken frontmatter still gets picked up by the wikilink).
    Returns: (orphan_ids, issues).
    """
    # which source pages are missing their raw file?
    orphans = {}                                 # source_id → raw_file (for reporting)
    for pid, info in pages.items():
        if info["dir"] != "sources":
            continue
        raw = info["post"].get("raw_file") or f"documents/{pid}.md"
        path = Path(raw) if Path(raw).is_absolute() else KB_DIR / raw
        if not path.exists():
            orphans[pid] = str(raw)

    # which entity/concept pages depend on each orphan?
    deps = defaultdict(set)
    for pid, info in pages.items():
        if info["dir"] not in {"entities", "concepts"}:
            continue
        for sid in (info["post"].get("sources", []) or []) + list(page_links.get(pid, [])):
            if sid in orphans:
                deps[sid].add(pid)

    issues = [{
        "severity": "P0",
        "type": "orphan_source",
        "page": sid,
        "detail": (f"Raw file `{raw}` missing; `sources/{sid}.md` still references it "
                   f"(dependents: {', '.join(sorted(deps[sid])) or '(none)'})"),
        "fix": "Auto-cascaded on every lint run.",
    } for sid, raw in orphans.items()]
    return issues

# ══════════════════════════════════════════════════
#  P1 checks — quality issues (suggest fix)
# ══════════════════════════════════════════════════
def check_orphan_pages(pages, page_links):
    """entity/concept page that nobody references."""
    issues = []
    incoming = Counter()
    for page_id, _ in pages.items():
        linked_ids = page_links.get(page_id, [])
        for linked_id in linked_ids:
            if linked_id != page_id:
                incoming[linked_id] += 1

    for page_id, info in pages.items():
        if info["dir"] not in {"entities", "concepts"}:
            continue
        if incoming.get(page_id, 0) == 0:
            issues.append({
                "severity": "P1",
                "type": "orphan_page",
                "page": page_id,
                "detail": f"No other page links to `{page_id}`",
                "fix": "remove the page if obsolete.",
            })
    return issues

def check_bidirectional_links(pages, page_links):
    """A → B then B → A. Only checks links between entity/concept/source pages."""
    issues = []
    valid_dirs = {"entities", "concepts", "sources"}
    
    for page_id, info in pages.items():
        if info["dir"] not in valid_dirs:
            continue
        linked_ids = page_links.get(page_id, [])
        for linked_id in linked_ids:
            if linked_id not in pages or linked_id == page_id:
                continue
            if pages[linked_id]["dir"] not in valid_dirs:
                continue
            target_link_ids = page_links.get(linked_id, [])
            if page_id not in target_link_ids:
                issues.append({
                    "severity": "P1",
                    "type": "missing_backlink",
                    "page": linked_id,
                    "linked_from": page_id,
                    "detail": f"`{page_id}` links to `{linked_id}` but `{linked_id}` does not link back",
                    "fix": f"Add `- [[{page_id}]]` under `## Related` in `{linked_id}.md`.",
                })
    return issues

# ══════════════════════════════════════════════════
#  P2 checks — LLM-based semantic suggestions (TODO)
# ══════════════════════════════════════════════════
def check_p2(pages, page_links):
    """P2: semantic suggestions powered by an LLM.

    TODO — Planned checks:
      - contradiction detection (scan `> ⚠️ contradiction` markers + cross-page conflicts)
      - missing pages (>=3 incoming wikilinks but no own file)
      - stale pages (updated > 30 days ago + newer material references the topic)
      - missing cross-references (topically related but unlinked)
      - tag inconsistency (e.g. `ai-safety` vs `ai_safety`)
      - mergeable pages (content overlap >70%)
      - new page suggestions
      - WebSearch knowledge-gap expansion
    """
    return []

# ══════════════════════════════════════════════════
#  Aggregators — one per severity
# ══════════════════════════════════════════════════
def check_p0(pages, page_links):
    return (check_broken_wikilinks(pages, page_links) +
            check_index_consistency(pages) +
            check_orphan_sources(pages, page_links))

def check_p1(pages, page_links):
    return (check_orphan_pages(pages, page_links) +
            check_bidirectional_links(pages, page_links))

# ══════════════════════════════════════════════════
#  Fix helpers — each mutates issue["fixed"] in place
# ══════════════════════════════════════════════════
def cascade_delete(orphan_issues, pages, kg):
    """For each orphan_source issue: delete the source, any entity/concept whose
    `sources` becomes empty, and scrub the dead ids out of every surviving page's
    `## Related` section. Records a one-line summary per orphan into issue['fixed'].
    Does NOT touch index.md — fix_p0 re-runs check_index_consistency afterwards.
    """
    # 1) Compute every dead id (orphan sources + entity/concept that lose all sources)
    dead = {i["page"] for i in orphan_issues}
    for page_id, info in pages.items():
        if info["dir"] not in {"entities", "concepts"}:
            continue
        srcs = info["post"].get("sources", []) or []
        if srcs and all(s in dead for s in srcs):
            dead.add(page_id)

    # 2) Delete every dead page from disk + KG
    for did in list(dead):
        info = pages.pop(did, None)
        if info and info["path"].exists():
            info["path"].unlink()
        kg.nodes.pop(did, None)
        kg.edges = [e for e in kg.edges
                    if did not in (e["source"], e["target"], e.get("source_doc"))]

    # 3) Scrub every surviving page: drop dead source ids + dead bullets in ## Related
    dead_link = re.compile(r'\[\[(?:' + "|".join(map(re.escape, dead)) + r')(?:\|[^\]]+)?\]\]')
    for page_id, info in pages.items():
        post = info["post"]
        old_srcs = post.get("sources", []) or []
        new_srcs = [s for s in old_srcs if s not in dead]

        # Only scrub bullets inside the ## Related section; never touch body prose.
        head, sep, related = post.content.partition("## Related")
        if sep:
            kept = [ln for ln in related.splitlines() if not dead_link.search(ln)]
            new_body = head + sep + "\n".join(kept)
        else:
            new_body = post.content

        if new_srcs == old_srcs and new_body == post.content:
            continue
        post["sources"], post.content, post["updated"] = new_srcs, new_body, TODAY
        info["path"].write_text(frontmatter.dumps(post), encoding="utf-8")

    # 4) Record outcome per orphan_source issue
    for i in orphan_issues:
        i["fixed"] = f"solved all pages related to {i['page']}"

    if dead:
        kg.save()
        print(f"  + saved KG ({len(kg.nodes)} nodes, {len(kg.edges)} edges)")

def add_index_entry(issue, pages, post):
    """Insert a bullet at the top of the matching `## <Section>` in post.content."""
    page_id = issue["page"]
    if page_id not in pages:
        return
    info = pages[page_id]
    section = f"## {info['dir'].capitalize()}\n\n"
    entry = f"- [{info['post'].get('title', page_id)}]({info['dir']}/{page_id}.md)\n"
    post.content = post.content.replace(section, section + entry, 1)
    issue["fixed"] = f"added index entry {info['dir']}/{page_id}.md"

def drop_index_entry(issue, post):
    """Drop the bullet line whose link target matches issue['target']."""
    target = issue["target"]
    post.content = "\n".join(ln for ln in post.content.splitlines() if target not in ln)
    issue["fixed"] = f"dropped index entry {target}"

def add_backlink(issue, pages):
    """Add `- [[<linked_from>]]` under `## Related` in the target page."""
    src, tgt = issue["linked_from"], issue["page"]
    if tgt not in pages:
        return
    info = pages[tgt]
    post = info["post"]
    bullet = f"- [[{src}]]"
    if bullet in post.content:
        return
    if "## Related" in post.content:
        post.content = post.content.replace("## Related", f"## Related\n\n{bullet}", 1)
    else:
        post.content = post.content.rstrip() + f"\n\n## Related\n\n{bullet}\n"
    post["updated"] = TODAY
    info["path"].write_text(frontmatter.dumps(post), encoding="utf-8")
    issue["fixed"] = f"added backlink {src} → {tgt}"


# ══════════════════════════════════════════════════
#  Fix appliers — P0 auto, P1 interactive
# ══════════════════════════════════════════════════
def fix_p0(issues, pages, kg):
    """Cascade-delete orphan sources, then reconcile index.md.
    Returns any *fresh* index issues that surfaced after the cascade so main can
    merge them into the overall issues list (for the report).
    """
    # 1) Cascade-delete (mutates orphan issues' `fixed` field in place)
    orphan_issues = [i for i in issues if i["type"] == "orphan_source"]
    if orphan_issues:
        cascade_delete(orphan_issues, pages, kg)

    # 2) Re-check index against the updated state — picks up both pre-existing
    #    issues AND new stale entries created by the cascade.
    fresh_index_issues = check_index_consistency(pages)
    if fresh_index_issues and INDEX_FILE.exists():
        post = frontmatter.load(INDEX_FILE)
        for i in fresh_index_issues:
            if i["type"] == "index_missing_entry":
                add_index_entry(i, pages, post)
            else:  # index_stale_entry
                drop_index_entry(i, post)
        post["updated"] = TODAY
        INDEX_FILE.write_text(frontmatter.dumps(post), encoding="utf-8")

    return fresh_index_issues

def fix_p1(issues, pages, auto_yes):
    """Walk each P1 issue and apply its fix (prompting unless --yes).
    Non-auto-fixable types are left with issue['fixed'] = None.
    """
    for i in issues:
        if i["type"] != "missing_backlink":
            continue                              # leave fixed=None
        if not auto_yes:
            print(f"\n🟡 [{i['type']}] `{i['page']}` — {i['detail']}")
            try:
                if input("Apply fix? [y/N]: ").strip().lower() not in {"y", "yes"}:
                    continue
            except EOFError:
                continue
        add_backlink(i, pages)

def fix_p2(issues, pages):
    """Apply LLM-suggested fixes (TODO)."""
    pass


# ══════════════════════════════════════════════════
#  Report rendering (runs at the very end, reads issue['fixed'])
# ══════════════════════════════════════════════════
def render_markdown_report(issues):
    """Render a P0/P1/P2 markdown report. Each issue's `fixed` field decides
    whether it shows as [✓] (with the fix action) or [ ] (with suggested fix)."""
    by_sev = defaultdict(list)
    for i in issues:
        by_sev[i["severity"]].append(i)

    n_p0, n_p1, n_p2 = (len(by_sev.get(s, [])) for s in ("P0", "P1", "P2"))
    n_fixed = sum(1 for i in issues if i.get("fixed"))
    lines = [
        f"## Wiki health check ({TODAY})", "",
        "### 📊 Summary",
        f"- Found: P0={n_p0}, P1={n_p1}, P2={n_p2} — fixed {n_fixed}",
        "",
    ]

    def section(emoji, label, severity, placeholder=None):
        lines.append(f"### {emoji} {label}")
        bucket = by_sev.get(severity, [])
        if not bucket:
            lines.append(placeholder or "- ✅ No issues.")
        else:
            for i in bucket:
                done = bool(i.get("fixed"))
                mark = "[✓]" if done else "[ ]"
                lines.append(f"- {mark} **[{i['type']}]** `{i['page']}` — {i['detail']}")
                if done:
                    lines.append(f"    - Fixed: {i['fixed']}")
                else:
                    lines.append(f"    - Suggested fix: {i['fix']}")
        lines.append("")

    section("🔴", "P0 — Must Fix", "P0")
    section("🟡", "P1 — Should Fix", "P1")
    section("🟢", "P2 — Suggestions", "P2",
            placeholder="- (none — TODO: LLM-based semantic checks, see TODO.md)")
    
    return "\n".join(lines)


# ══════════════════════════════════════════════════
#  Main
# ══════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(description="LLM Wiki Lint — health check")
    parser.add_argument("--fix", action="store_true",
                        help="Interactively fix P1 issues after auto-fixing P0.")
    parser.add_argument("--yes", action="store_true",
                        help="With --fix: silently apply fixable P1 issues.")
    args = parser.parse_args()

    print(f"=== LLM Wiki Lint ===\nWiki directory: {WIKI_DIR}\n")
    pages = load_all_pages()
    links = get_linked_pages(pages)

    # ── Run all checks; every issue starts with fixed=None ──
    issues = check_p0(pages, links) + check_p1(pages, links) + check_p2(pages, links)
    for i in issues:
        i["fixed"] = None

    # ── Step 1: always auto-fix every P0 ──
    p0_issues = [i for i in issues if i["severity"] == "P0"]
    if p0_issues:
        kg = KnowledgeGraph(json.loads(GRAPH_FILE.read_text())) if GRAPH_FILE.exists() else KnowledgeGraph()
        fresh_index_issues = fix_p0(p0_issues, pages, kg)
        def _key(i):
            return (i["type"], i.get("target") or i["page"])
        existing = {_key(i): i for i in p0_issues if i["type"].startswith("index_")}
        for fi in fresh_index_issues:
            orig = existing.get(_key(fi))
            if orig is not None:
                orig["fixed"] = fi.get("fixed")
            else:
                issues.append(fi)

    # ── Step 2: --fix → P1 (interactive, or silent with --yes) ──
    if args.fix:
        p1_issues = [i for i in issues if i["severity"] == "P1"]
        if p1_issues:
            fix_p1(p1_issues, pages, args.yes)

    # ── Step 3: report → outputs/lint_log.md + stdout ──
    report = render_markdown_report(issues)
    print(report)
    
    # ── Step 4: short summary into wiki/log.md ──
    n = lambda sev: sum(1 for i in issues if i["severity"] == sev)
    n_fix = lambda sev: sum(1 for i in issues if i["severity"] == sev and i.get("fixed"))
    lint_entry = (
        f"## [{TODAY}] lint | health check\n"
        f"- Issues found: P0={n('P0')}, P1={n('P1')}, P2={n('P2')}\n"
        f"- Issues fixed: P0={n_fix('P0')}, P1={n_fix('P1')}"
    )
    update_log(lint_entry)


if __name__ == "__main__":
    main()
