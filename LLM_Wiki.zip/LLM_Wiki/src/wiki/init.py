"""
LLM Wiki Init
Creates and initializes a new knowledge base directory structure.
Equivalent to /wiki init in second-brain-skill.

Usage:
    python init.py
    python init.py --kb-dir /path/to/custom/kb
"""

import os
import argparse
from pathlib import Path
import frontmatter

from src.utils.config import KB_DIR as DEFAULT_KB_DIR, TODAY

def init_kb(kb_dir: Path):
    """Initialize knowledge base directory structure"""

    raw_dir = kb_dir / "documents"
    wiki_dir = kb_dir / "wiki"
    sources_dir = wiki_dir / "sources"
    entities_dir = wiki_dir / "entities"
    concepts_dir = wiki_dir / "concepts"
    analyses_dir = wiki_dir / "analyses"

    # Create directories
    for d in [raw_dir, wiki_dir, sources_dir, entities_dir, concepts_dir, analyses_dir]:
        os.makedirs(d, exist_ok=True)

    # Write index.md
    index_file = wiki_dir / "index.md"
    if not index_file.exists():
        post = frontmatter.Post(
            content=(
                f"# Knowledge Base Index\n\n"
                f"## Sources\n\n"
                f"## Entities\n\n"
                f"## Concepts\n\n"
                f"## Analyses\n\n"
            ),
            title="Knowledge Base Index",
            type="index",
            created=TODAY,
            updated=TODAY
        )
        index_file.write_text(frontmatter.dumps(post), encoding="utf-8")
        
    # Write log.md
    log_file = wiki_dir / "log.md"
    if not log_file.exists():
        post = frontmatter.Post(
            content=(
                f"## [{TODAY}] init | Knowledge Base Created\n"
                f"- Initialized directory structure\n"
                f"- Created index.md, log.md, overview.md\n\n"
            ),
            title="Wiki Log",
            type="log",
            created=TODAY,
            updated=TODAY
        )   
        log_file.write_text(frontmatter.dumps(post), encoding="utf-8")
        
    # Write overview.md
    overview_file = wiki_dir / "overview.md"
    if not overview_file.exists():
        post = frontmatter.Post(
            content=(
                f"# Knowledge Base Overview\n\n"
                f"- **Documents ingested**: 0\n"
                f"- **Source pages**: 0\n"
                f"- **Entity pages**: 0\n"
                f"- **Concept pages**: 0\n"
                f"- **Knowledge graph nodes**: 0\n"
                f"- **Knowledge graph edges**: 0\n"
                f"- **Last updated**: {TODAY}\n"
            ),
            title="Knowledge Base Overview",
            type="overview",
            created=TODAY,
            updated=TODAY
        )
        overview_file.write_text(frontmatter.dumps(post), encoding="utf-8")
        
    # Write conventions.md 
    conventions_file = wiki_dir / "conventions.md"
    if not conventions_file.exists():
        post = frontmatter.Post(
            content=(
                f"# Conventions\n\n"
                f"## General\n\n"
                f"- Language: English\n\n"
                f"## Query\n\n"
                f"## Ingest\n\n"
                f"## Lint\n\n"
            ),
            title="Conventions",
            type="conventions",
            created=TODAY,
            updated=TODAY
        )
        conventions_file.write_text(frontmatter.dumps(post), encoding="utf-8")
        
    

    print(f"   Knowledge base initialized at: {kb_dir}")
    print(f"   Structure:")
    print(f"   {kb_dir}/")
    print(f"   ├── documents/        (place raw materials here)")
    print(f"   └── wiki/")
    print(f"       ├── index.md")
    print(f"       ├── log.md")
    print(f"       ├── overview.md")
    print(f"       ├── conventions.md")
    print(f"       ├── sources/")
    print(f"       ├── entities/")
    print(f"       ├── concepts/")
    print(f"       └── analyses/")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Initialize LLM Wiki knowledge base")
    parser.add_argument("--kb-dir", type=str, default=None,
                        help="Knowledge base directory path")
    args = parser.parse_args()

    kb_dir = Path(args.kb_dir) if args.kb_dir else DEFAULT_KB_DIR
    init_kb(kb_dir)
