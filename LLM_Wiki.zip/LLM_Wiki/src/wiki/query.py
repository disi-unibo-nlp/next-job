"""
LLM Wiki Query — Single Question (3 LLM calls)

Pipeline:
  LLM call 1: Read index.md + question → route to pages + generate search terms
  Code:       5-step retrieval (wiki sections, entity/concept pages, analysis pages,
              grep wiki for routing misses, keyword search raw docs)
  LLM call 2: Context + question → short answer
  LLM call 3: Assess writeback → LLM decides new relationships to persist

Key insight: LLM reads the wiki index (which includes page summaries and key facts)
to simultaneously route AND generate semantic search terms in a single call.
Code then handles all retrieval deterministically. 

Usage:
    python query.py "What is the capital of France?"
    python query.py "Who founded OpenAI?" --no-writeback
"""

import json
import argparse
import frontmatter


from src.utils.config import (
    RAW_DIR, ANALYSES_DIR, GRAPH_FILE, TODAY, SECTION_CONFIGS,
    ENABLE_THINKING, ROUTE_TOKENS, QUERY_TOKENS, WRITEBACK_TOKENS,
    TOTAL_CONTEXT_BUDGET, 
)
from src.utils.kg import KnowledgeGraph
from src.utils.helper import (
    load_all_pages, list_analyses, load_index, ensure_dirs,
    call_llm,
    parse_json_response, update_log, strip_thinking, extract_sections, stem_text,
    paragraph_term_score,
    is_valid_edge, add_cross_reference
)
from src.utils.prompt import (
    QUERY_ROUTE_PROMPT, QUERY_PROMPT, WRITEBACK_PROMPT,
)

# ── Init ──
ensure_dirs()
INDEX_CONTENT = load_index()

# ══════════════════════════════════════════════════
#  Utilities
# ══════════════════════════════════════════════════
# Minimum paragraph length (chars) for ranked candidates.
# Drops boilerplate like blank lines, single-line headers, "## Related" stubs.
MIN_PARA_CHARS = 30
# Per-document char cap when keyword-searching all raw documents as a fallback.
RAW_FALLBACK_DOC_CAP = 3000
RAW_FALLBACK_MIN_HITS = 2
RAW_FALLBACK_TOP_K = 2

def _split_paragraphs(text):
    """Split markdown text into clean paragraphs, dropping link-list noise."""
    if not text:
        return []
    out = []
    for para in text.split("\n\n"):
        para = para.strip()
        if len(para) < MIN_PARA_CHARS:
            continue
        # Drop pure backlink dumps from "## Related" sections
        if para.startswith("- [[") or para.startswith("## Related"):
            continue
        out.append(para)
    return out

def create_analysis_page(analysis_id, question, answer, related_pages, analysis=""):
    """Create an analysis page with answer and LLM-synthesized cross-document insight."""
    filepath = ANALYSES_DIR / f"{analysis_id}.md"
    if filepath.exists():
        return False
    
    related_lines = [f"- [[{rid}]]" for rid in related_pages] or ["(none yet)"]
    related_text = "\n".join(related_lines)
    
    post = frontmatter.Post(
        content=(
            f"# {question}\n\n"
            f"## Answer\n\n{answer}\n\n"
            f"## Cross-Document Analysis\n\n"
            f"{analysis}\n\n"
            f"## Related\n\n"
            f"{related_text}\n"
        ),
        title=analysis_id,
        type="analysis",
        created=TODAY,
        updated=TODAY,
        source=question,
    )
    filepath.write_text(frontmatter.dumps(post), encoding="utf-8")
    return True

# ══════════════════════════════════════════════════
#  Call 1: Understand question (route + search term extraction)
# ══════════════════════════════════════════════════
def understand_question(question):
    """
    Read index.md + question → route to pages AND generate search terms.
    """
    analyses = list_analyses()
    analyses_str = "\n".join(f"- {a}" for a in analyses) if analyses else "(none)"
    
    prompt = QUERY_ROUTE_PROMPT.format(
        question=question,
        index_content=INDEX_CONTENT,
        analyses_list=analyses_str,
    )
    raw, tokens = call_llm(prompt, max_tokens=ROUTE_TOKENS)
    if raw:
        _, raw = strip_thinking(raw)
        data = parse_json_response(raw)
        return data, tokens      
    return {"source_pages": [], "entity_pages": [],
            "concept_pages": [], "analysis_pages": [],
            "search_terms": []}, 0


# ══════════════════════════════════════════════════
#  Deterministic retrieval based on routing output
#
#  All collectors return a list of (fuzzy, exact, label, paragraph) tuples
#  so retrieve_wiki() can rank every candidate globally before filling
#  the context budget. This mirrors the tutorial.ipynb pipeline that
#  achieved EM 59.57%.
# ══════════════════════════════════════════════════
def collect_from_wiki_pages(page_ids, wiki_pages, search_terms):
    """Paragraph-level extraction from routed wiki pages (entity/concept/
    source/analysis), using SECTION_CONFIGS to pull only the meaningful
    sections. Each paragraph is scored against search_terms.

    Returns list of (fuzzy, exact, label, paragraph) tuples.
    """
    out = []
    for page_id in page_ids:
        if page_id not in wiki_pages:
            continue
        post = wiki_pages[page_id]["post"]
        title = post.get("title", page_id)
        page_type = post.get("type", "unknown")
        body = post.content

        sections = SECTION_CONFIGS.get(page_type, [])
        page_content = extract_sections(body, sections) if sections else body
        if not page_content:
            page_content = body
        if not page_content:
            continue

        label = f"[{title} ({page_type})]"
        for para in _split_paragraphs(page_content):
            fh, eh = paragraph_term_score(para, search_terms)
            if fh > 0:
                out.append((fh, eh, label, para))
    return out

def grep_wiki_for_routing_misses(wiki_pages, search_terms, already_seen):
    """Safety net: paragraph-level grep over wiki pages NOT routed by the LLM.
    Returns (fuzzy, exact, label, paragraph) tuples.
    """
    out = []
    for page_id, info in wiki_pages.items():
        if page_id in already_seen:
            continue
        post = info["post"]
        title = post.get("title", page_id)
        body = post.content
        label = f"[{title} (grep)]"
        for para in _split_paragraphs(body):
            fh, eh = paragraph_term_score(para, search_terms)
            if fh > 0:
                out.append((fh, eh, label, para))
    return out

def collect_from_raw_documents(source_page_ids, search_terms):
    """Paragraph-level extraction from RAW documents pointed at by the LLM's
    routed source_pages. Returns (fuzzy, exact, label, paragraph) tuples.

    A wiki source page ID is the same stem as its raw document filename.
    """
    out = []
    seen_stems = set()
    for page_id in source_page_ids:
        raw_path = RAW_DIR / f"{page_id}.md"
        if not raw_path.exists():
            continue
        seen_stems.add(raw_path.stem.lower())

        raw_text = raw_path.read_text(encoding="utf-8")
        # Strip YAML frontmatter if present
        if raw_text.startswith("---"):
            _, _, body = raw_text.partition("---")
            _, _, body = body.partition("---")
            body = body.strip()
        else:
            body = raw_text.strip()
        if not body:
            continue

        label = f"[{page_id} (raw)]"
        for para in _split_paragraphs(body):
            fh, eh = paragraph_term_score(para, search_terms)
            if fh > 0:
                out.append((fh, eh, label, para))
    return out, seen_stems

def search_raw_documents(search_terms, exclude_stems=None):
    """Final fallback — keyword-search EVERY raw document, paragraph by paragraph.

    Picks the top-RAW_FALLBACK_TOP_K documents whose full-text fuzzy score is
    >= RAW_FALLBACK_MIN_HITS, then for each takes the best paragraphs up to
    RAW_FALLBACK_DOC_CAP chars.

    Returns (fuzzy, exact, label, paragraph) tuples. This is the safety net
    for the (frequent) case where LLM routing misses the actually-relevant
    source document.
    """
    exclude_stems = exclude_stems or set()
    doc_hits = []
    for raw_path in RAW_DIR.glob("*.md"):
        if raw_path.stem.lower() in exclude_stems:
            continue
        try:
            content = raw_path.read_text(encoding="utf-8")
        except Exception:
            continue
        if not content:
            continue
        doc_fh, _ = paragraph_term_score(content, search_terms)
        if doc_fh < RAW_FALLBACK_MIN_HITS:
            continue
        doc_hits.append((doc_fh, raw_path))

    # Top documents by full-text fuzzy score
    doc_hits.sort(key=lambda x: -x[0])
    doc_hits = doc_hits[:RAW_FALLBACK_TOP_K]

    out = []
    for _, raw_path in doc_hits:
        content = raw_path.read_text(encoding="utf-8")
        if content.startswith("---"):
            _, _, body = content.partition("---")
            _, _, body = body.partition("---")
            body = body.strip()
        else:
            body = content.strip()

        scored = []
        for para in _split_paragraphs(body):
            fh, eh = paragraph_term_score(para, search_terms)
            if fh > 0:
                scored.append((fh, eh, para))
        scored.sort(key=lambda x: (-x[0], -x[1]))

        # Cap how much we take from each fallback document
        chars = 0
        label = f"[{raw_path.stem} (raw-fallback)]"
        for fh, eh, para in scored:
            if chars + len(para) > RAW_FALLBACK_DOC_CAP:
                break
            out.append((fh, eh, label, para))
            chars += len(para)
    return out
    
def get_kg_info(node_ids, kg):
    """Get KG edges for given node IDs as compact relational supplement."""
    all_node_ids = set(node_ids)
    edges = kg.get_edges_for_nodes(all_node_ids)
    if edges:
        parts = []
        for edge in edges:
            src_name = kg.nodes.get(edge["source"], {}).get("name", edge["source"])
            tgt_name = kg.nodes.get(edge["target"], {}).get("name", edge["target"])
            line = f"{src_name} —[{edge['relation']}]→ {tgt_name}"
            parts.append(line)
        if parts:
            content = "KG Relations:\n" + "\n".join(parts)
            return content
    return ""
    
def retrieve_wiki(routing, wiki_pages, kg):
    """
    Budget-bounded GLOBAL retrieval pipeline.

    Collects candidate paragraphs from five sources, scores each paragraph
    with paragraph_term_score(), then ranks ALL of them together by
    (fuzzy_hits desc, exact_hits desc) and greedily fills TOTAL_CONTEXT_BUDGET.

    Sources:
      1. LLM-routed source/entity/concept/analysis wiki pages
      2. LLM-routed source pages → raw document paragraphs
      3. Grep over non-routed wiki pages (safety net for routing misses)
      4. Keyword search over all raw documents (safety net for source misses)
      + KG edge facts (compact relational supplement, appended last)

    The global ranking is the key win over the previous "guaranteed parts
    first, ranked extras after" design: a long but tangential routed page
    can no longer crowd out the actually-relevant paragraph.
    """
    search_terms = routing.get("search_terms", []) or []
    source_pages = routing.get("source_pages", []) or []
    entity_pages = routing.get("entity_pages", []) or []
    concept_pages = routing.get("concept_pages", []) or []
    analysis_pages = routing.get("analysis_pages", []) or []

    routed_page_ids = [pid for pid in
                       (source_pages + entity_pages + concept_pages + analysis_pages)
                       if pid in wiki_pages]
    already_seen = set(routed_page_ids)
    matched_nodes = list(dict.fromkeys(entity_pages + concept_pages + routed_page_ids))

    # ── Build one global candidate pool ──
    candidates = []  # list of (fuzzy, exact, label, paragraph)

    # 1) Routed wiki pages (section-aware paragraphs)
    candidates.extend(collect_from_wiki_pages(routed_page_ids, wiki_pages, search_terms))

    # 2) Routed source pages → raw document paragraphs
    raw_routed, retrieved_raw_stems = collect_from_raw_documents(source_pages, search_terms)
    candidates.extend(raw_routed)

    # 3) Grep over non-routed wiki pages
    grep_hits = grep_wiki_for_routing_misses(wiki_pages, search_terms, already_seen)
    candidates.extend(grep_hits)
    # Pages discovered via grep also count as matched nodes (for KG + writeback)
    for _, _, label, _ in grep_hits:
        # label looks like "[<title> (grep)]" — but we need the page_id, not title.
        # Easier: re-derive from grep loop. Skip; matched_nodes update below is fine.
        pass
    # Recompute grep page IDs cheaply
    grep_page_ids = []
    for page_id, info in wiki_pages.items():
        if page_id in already_seen:
            continue
        body = info["post"].content
        fh, _ = paragraph_term_score(body, search_terms)
        if fh > 0:
            grep_page_ids.append(page_id)
    matched_nodes.extend(grep_page_ids)

    # 4) Final fallback — keyword search every raw document
    fallback_hits = search_raw_documents(search_terms, exclude_stems=retrieved_raw_stems)
    candidates.extend(fallback_hits)

    # ── Global rank: (fuzzy desc, exact desc), tiebreak label for determinism ──
    candidates.sort(key=lambda x: (-x[0], -x[1]))

    # ── Greedy budget fill ──
    seen_paragraphs = set()
    context_parts = []
    total_chars = 0
    for fh, eh, label, para in candidates:
        # Dedup identical paragraph text across sources
        key = (label, para[:120])
        if key in seen_paragraphs:
            continue
        seen_paragraphs.add(key)

        block = f"{label}\n{para}"
        if total_chars + len(block) > TOTAL_CONTEXT_BUDGET:
            remaining = TOTAL_CONTEXT_BUDGET - total_chars
            # Only bother with a truncated tail if it's substantial
            if remaining > 400:
                context_parts.append(f"{label}\n{para[: remaining - len(label) - 2]}")
            break
        context_parts.append(block)
        total_chars += len(block) + 2  # +2 for the joining "\n\n"

    # ── KG edge supplement (compact, always appended if room remains) ──
    kg_info = get_kg_info(entity_pages + concept_pages + grep_page_ids, kg)
    if kg_info and total_chars + len(kg_info) <= TOTAL_CONTEXT_BUDGET:
        context_parts.append(kg_info)

    context = "\n\n".join(context_parts)
    matched_nodes = list(dict.fromkeys(matched_nodes))
    return context, matched_nodes

    
# ══════════════════════════════════════════════════
#  Call 2: Answer question based on retrieved context
# ══════════════════════════════════════════════════
def generate_answer(question, context):
    """LLM call to generate answer based on retrieved wiki context."""
    prompt = QUERY_PROMPT.format(
        question=question,
        context=context,
    )
    raw, tokens = call_llm(prompt, max_tokens=QUERY_TOKENS, 
                           enable_thinking=ENABLE_THINKING)
    if raw:
        thinking, answer = strip_thinking(raw)
        return answer, thinking, tokens
    return "unanswerable", "", 0


# ══════════════════════════════════════════════════
#  Call 3: LLM assesses what new knowledge to write back (if enabled)
# ══════════════════════════════════════════════════
def perform_writeback(question, answer, thinking, matched_nodes, kg):
    """LLM call #3 + execution: assess what to write back, then do it.

    Steps:
      1. LLM evaluates which new edges / analysis to persist
      2. Validate & add edges to KG + cross-references in wiki pages
      3. Save analysis page if LLM found a non-trivial insight

    Returns (writeback_count, tokens_used).
    """
    valid_nodes = [nid for nid in matched_nodes if nid in kg.nodes]
    if len(valid_nodes) < 2:
        return 0, 0
    
    node_info = [f"{nid} ({kg.nodes[nid]['name']})" for nid in valid_nodes]
    prompt = WRITEBACK_PROMPT.format(
        question=question,
        answer=answer,
        thinking=(thinking if thinking else "(none)"),
        matched_nodes=", ".join(node_info),
    )
    raw, tokens = call_llm(prompt, max_tokens=WRITEBACK_TOKENS)
    if not raw:
        return 0, tokens
    _, raw = strip_thinking(raw)
    data = parse_json_response(raw)
    if not data:
        return 0, tokens

    writeback_count = 0
    # ── Add validated edges ──
    for edge in data.get("new_edges", []):
        src = edge.get("source_id", "")
        tgt = edge.get("target_id", "")
        rel = edge.get("relation", "related_to")
        if is_valid_edge(src, tgt, kg):
            kg.add_edge(src, tgt, rel)
            add_cross_reference(src, tgt)
            add_cross_reference(tgt, src)
            writeback_count += 1
            
    # ── Save analysis page when it connects 2+ matched nodes ──
    # Looser gate than before (was: 3+ entities, len>=80) so analyses
    # accumulate and later multi-hop queries can short-circuit via the
    # analysis_pages routing. Still requires a non-trivial sentence.
    analysis = data.get("analysis", "").strip()
    analysis_id = data.get("analysis_id", "").strip()
    if analysis and analysis_id and len(valid_nodes) >= 2 and len(analysis) >= 40:
        if create_analysis_page(analysis_id, question, answer, valid_nodes, analysis):
            writeback_count += 1
            
    return writeback_count, tokens
    
    
# ══════════════════════════════════════════════════
#  Main Query Pipeline
# ══════════════════════════════════════════════════
def ask_wiki(question, wiki_pages, kg, enable_writeback=True):
    """
    Execute a single wiki query with up to 3 LLM calls:
      Call 1: understand_question() — read index.md, route to relevant pages
      Call 2: generate_answer() — answer based on retrieved context
      Call 3: assess_writeback() — LLM decides new relationships (if enabled)
    Returns dict with answer + metadata.
    """
    total_tokens = 0
    
    # LLM calls #1: Route via index, then generate search terms from content
    routing, understand_tokens = understand_question(question)
    total_tokens += understand_tokens
    
    # Retrieve context based on routing (deterministic code, no LLM)
    wiki_context, matched_nodes = retrieve_wiki(routing, wiki_pages, kg)
    
    # LLM call #2: Generate answer based on retrieved context
    answer, thinking, answer_tokens = generate_answer(question, wiki_context)
    total_tokens += answer_tokens
    
    # LLM call #3: Assess writeback needs (if enabled)
    writebacks = 0
    if enable_writeback:
        writebacks, writeback_tokens = perform_writeback(question, answer, thinking, matched_nodes, kg)
        total_tokens += writeback_tokens
        
    return {
        "answer": answer,
        "thinking": thinking,
        "matched_nodes": matched_nodes,
        "wikicontext": wiki_context,
        "tokens": total_tokens,
        "writebacks": writebacks,
    }

# ══════════════════════════════════════════════════
#  CLI — interactive single-question mode
# ══════════════════════════════════════════════════
def main(args):
    print(f"=== LLM Wiki Query ===")
  
    # --------------------------------------
    # Step 1: Load wiki (graph + pages)
    print("\nStep 1: Loading wiki knowledge base...")
    with open(GRAPH_FILE, "r", encoding="utf-8") as f:
        graph_dict = json.load(f)
        
    kg = KnowledgeGraph(graph_dict)
    wiki_pages = load_all_pages()
    print(f"    {len(kg.nodes)} nodes, {len(kg.edges)} edges, {len(wiki_pages)} pages")
    
    # --------------------------------------
    # Step 2: Query processing and retrieval
    print("\nStep 2: Processing query and retrieving context...")
    result = ask_wiki(args.question, wiki_pages, kg, enable_writeback=not args.no_writeback)
    print(f"    Question:  {args.question}")
    print(f"    Answer:    {result['answer']}")
    print(f"    Nodes:     {result['matched_nodes']}")
    print(f"    Tokens:    {result['tokens']}")

    # --------------------------------------
    # Step 3: Writeback if needed
    print("\nStep 3: Checking for writeback needs...")
    if result['writebacks'] > 0:
        kg.save()
        # Update log
        query_entry = f"## [{TODAY}] query | {args.question[:50].strip()}\n- Answer: {result['answer'][:100].strip()}\n- Writebacks: {result['writebacks']}"
        update_log(query_entry)
        print(f"    Writeback: {result['writebacks']} updates to wiki")
    else:
        print(f"    No writeback needed.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="LLM Wiki Query")
    parser.add_argument("question", type=str, help="Question to ask the wiki")
    parser.add_argument("--no-writeback", action="store_true", help="Disable knowledge writeback")
    args = parser.parse_args()
    main(args)