"""
LLM Wiki Batch Evaluation
Calls 02_query.query_once() for each question in qa_pairs.json,
measures EM / Rouge-L / BERTScore, tracks batch progression.

Output format matches rag_results.json for direct comparison.

Usage:
    python evaluate.py
    python evaluate.py
"""
import json
import time
import re
import string
import argparse
from tqdm import tqdm

from rouge_score import rouge_scorer
from bert_score import score as bert_score_fn

from src.utils.config import (
     MODEL_TAG, TODAY, DATA_DIR_NAME, GRAPH_FILE, OUTPUT_DIR, QA_FILE,
     LLM_MODEL, ENABLE_THINKING,
     BATCH_SIZE, NO_WRITEBACK,
)
from src.utils.kg import KnowledgeGraph
from src.utils.helper import load_all_pages, update_log, get_linked_pages

from src.wiki.query import ask_wiki
from src.wiki.lint import check_p0, fix_p0

# ── Evaluation Metrics ──
rouge = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)

def normalize_answer(s):
    s = s.lower()
    s = "".join(ch for ch in s if ch not in set(string.punctuation))
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    s = " ".join(s.split())
    return s

def exact_match(prediction, ground_truths):
    pred_norm = normalize_answer(prediction)
    return any(normalize_answer(gt) == pred_norm for gt in ground_truths)

def evaluate_rouge(prediction, ground_truths):
    scores = [rouge.score(gt, prediction)['rougeL'].fmeasure for gt in ground_truths]
    return max(scores)

# ── Main ──
def main():
    parser = argparse.ArgumentParser(description="LLM Wiki Batch Evaluation")
    parser.add_argument("--debug", action="store_true",
                        help="Enable debug mode (only first 5 questions, no writeback)")
    args = parser.parse_args()
    enable_writeback = not NO_WRITEBACK
    
    print("=== LLM Wiki Batch Evaluation ===\n")
    # --------------------------------------
    # Step 1: Load wiki (graph + pages)
    print("\nStep 1: Loading wiki knowledge base...")
    with open(GRAPH_FILE, "r", encoding="utf-8") as f:
        graph_dict = json.load(f)
    kg = KnowledgeGraph(graph_dict)
    wiki_pages = load_all_pages()
    initial_edges = len(kg.edges)
    print(f"    {len(kg.nodes)} nodes, {len(kg.edges)} edges, {len(wiki_pages)} pages")
    
    # --------------------------------------
    # Step 2: Load QA pairs
    print("\nStep 2: Loading QA pairs...")
    with open(QA_FILE, "r", encoding="utf-8") as f:
        qa_pairs = json.load(f)
    qa_pairs = [q for q in qa_pairs]
    print(f"    QA: {len(qa_pairs)} answerable questions")
    print(f"    Model: {LLM_MODEL}")
    print(f"    Writeback: {'ENABLED' if enable_writeback else 'DISABLED'}")
    print(f"    Batch size: {BATCH_SIZE}\n")

    if args.debug:
        print(">>> Running in DEBUG mode: only first 5 questions, no writeback")
        enable_writeback = False
        qa_pairs = qa_pairs[:5]
    
    # --------------------------------------
    # Step 3: Evaluation loop
    print("\nStep 3: Evaluating QA pairs...")
    results = []
    total_em = 0
    total_rouge_l = 0.0
    total_bert_f1 = 0.0
    total_latency = 0.0
    total_tokens = 0
    total_writebacks = 0
    
    pbar = tqdm(qa_pairs, desc="Evaluating", unit="q",
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}] EM={postfix[0]:.2%} ROUGE-L={postfix[1]:.2%}",
                postfix=[0.0, 0.0])
    for i, qa in enumerate(qa_pairs):
        question = qa["question"]
        ground_truths = qa["answers"]["text"]

        t_start = time.time()
        result = ask_wiki(question, wiki_pages, kg, enable_writeback=enable_writeback)
        t_end = time.time()
        latency = t_end - t_start

        answer = result["answer"] if result["answer"] else "empty"
        em = exact_match(answer, ground_truths)
        rouge_l = evaluate_rouge(answer, ground_truths)
        
        result = {
            "qa_id": qa["qa_id"],
            "question": question,
            "ground_truths": ground_truths,
            "predicted": answer,
            "exact_match": em,
            "rouge_l": rouge_l,
            "bert_f1": 0.0,  # Placeholder, will be filled later
            "latency": round(latency, 3),
            "tokens": result["tokens"],
            "matched_graph_nodes": result["matched_nodes"],
            "writebacks": result["writebacks"],
        }
        results.append(result)
        total_em += em
        total_rouge_l += rouge_l
        total_latency += latency
        total_tokens += result["tokens"]
        total_writebacks += result["writebacks"]
        
        pbar.update(1)
        pbar.postfix[0] = total_em / pbar.n
        pbar.postfix[1] = total_rouge_l / pbar.n
        
        # After the batch_sized number of questions, compute batch-level BERTScore and optionally write back to wiki
        if (i + 1) % BATCH_SIZE == 0 or (i + 1) == len(qa_pairs):
            print(f"\n     Computing BERTScore for batch {(i + 1) // BATCH_SIZE}...")
            batch_start_idx = len(results) - (i % BATCH_SIZE) - 1
            batch_preds = [res["predicted"] for res in results[batch_start_idx:]]
            batch_refs = [res["ground_truths"][0] for res in results[batch_start_idx:]]
            _, _, batch_bert_tensor = bert_score_fn(
                batch_preds, batch_refs, lang="en", verbose=False,
            )
            for j in range(len(batch_preds)):
                results[batch_start_idx + j]["bert_f1"] = batch_bert_tensor[j].item()
                total_bert_f1 += batch_bert_tensor[j].item()
            
            # Optional: write back to wiki after each batch
            if enable_writeback:
                links = get_linked_pages(wiki_pages)
                p0_issues = check_p0(wiki_pages, links)
                if p0_issues:
                    fix_p0(p0_issues, wiki_pages, kg)
                    print(f"     Auto-fixed {len(p0_issues)} P0 issues")
                    wiki_pages = load_all_pages()
                    print(f"     Wiki updated. Graph now has {len(kg.edges)} edges.")
                    
    # ── Summary and Output ──        
    n = len(qa_pairs)
    summary = {
        "model": LLM_MODEL,
        "method": "llm_wiki",
        "num_questions": n,
        "exact_match": round(total_em / n, 4),
        "rouge_l": round(total_rouge_l / n, 4),
        "bert_f1": round(total_bert_f1 / n, 4),
        "avg_latency_s": round(total_latency / n, 3),
        "avg_tokens": round(total_tokens / n, 1),
        "writeback_enabled": enable_writeback,
        "total_writebacks": total_writebacks,
        "graph_nodes_final": len(kg.nodes),
        "graph_edges_initial": initial_edges,
        "graph_edges_final": len(kg.edges),
    }
    output = {"summary": summary, "results": results}
    data_match = re.search(r'([^/]+)(?=_data)', DATA_DIR_NAME)
    short_data_name = data_match.group(1) if data_match else "dataset"
    if ENABLE_THINKING:
        output_file = OUTPUT_DIR / f"{MODEL_TAG}_{short_data_name}_wiki_thinking_results.json"
    else:
        output_file = OUTPUT_DIR / f"{MODEL_TAG}_{short_data_name}_wiki_results.json"

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    # Update wiki log
    evaluate_entry = (
        f"## [{TODAY}] query | Batch evaluation ({n} questions)\n\n"
        f"- EM: {summary['exact_match']:.2%}, "
        f"Rouge-L: {summary['rouge_l']:.2%}, BERT-F1: {summary['bert_f1']:.2%}\n"
        f"- Writebacks: {total_writebacks}\n"
        f"- Graph edges: {initial_edges} → {len(kg.edges)}"
    )
    update_log(evaluate_entry)
    
    # Print report
    print(f"\n{'='*50}")
    print(f"  LLM Wiki Evaluation Results")
    print(f"{'='*50}")
    print(f"  Model:            {LLM_MODEL}")
    print(f"  Exact Match:      {summary['exact_match']:.2%}")
    print(f"  Rouge-L:          {summary['rouge_l']:.2%}")
    print(f"  BERT-F1:          {summary['bert_f1']:.2%}")
    print(f"  Avg Latency:      {summary['avg_latency_s']:.3f}s")
    print(f"  Avg Tokens:       {summary['avg_tokens']}")
    print(f"  Total Writebacks: {summary['total_writebacks']}")
    print(f"  Graph:            {initial_edges} → {summary['graph_edges_final']} edges")
    print(f"\nOutput: {output_file}")

if __name__ == "__main__":
    main()
