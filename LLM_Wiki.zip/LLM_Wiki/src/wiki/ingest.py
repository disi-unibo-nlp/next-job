"""
LLM Wiki Ingest Pipeline
Following second-brain-skill workflow (SCHEMA.md + ingest.md)

Workflow:
  1. Discover new materials (skip already-ingested docs via index.md)
  2. Read raw document
  3. LLM compilation → structured JSON
  4. Create source summary page (wiki/sources/)
  5. Create/update entity & concept pages (wiki/entities/, wiki/concepts/)
  6. Maintain existing pages linked to new nodes if mentioned
  7. Update index.md, log.md, overview.md and knowledge_graph.json
"""

import json
import re
import glob
import time
import frontmatter
from pathlib import Path

from src.utils.config import (
    RAW_DIR, KB_DIR, WIKI_DIR, SOURCES_DIR, ENTITIES_DIR, CONCEPTS_DIR,
    GRAPH_FILE, TODAY,
    LLM_MODEL, MAX_MODEL_TOKENS, INGEST_TOKENS, RECONCILE_TOKENS,
)
from src.utils.helper import (
    call_llm, check_llm_connection, 
    parse_json_response, sanitize_filename, strip_thinking, update_log, ensure_dirs,
)
from src.utils.kg import KnowledgeGraph
from src.utils.prompt import INGEST_PROMPT, RECONCILE_PROMPT

from src.wiki.init import init_kb

# ── Init ──
ensure_dirs()


# ══════════════════════════════════════════════════
#  Utilities
# ══════════════════════════════════════════════════

def get_ingested_sources():
    """Read index.md to find already-ingested source filenames."""
    index_file = WIKI_DIR / "index.md"
    if not index_file.exists():
        return set()
    with open(index_file, "r", encoding="utf-8") as f:
        content = f.read()
    ingested = set()
    for m in re.finditer(r'\[.*?\]\(sources/(.*?)\.md\)', content):
        ingested.add(m.group(1))
    return ingested

def is_complete_result(data):
    """Check if LLM output has all required fields with content"""
    if not data:
        return False
    has_entities = len(data.get("entities", [])) > 0 or len(data.get("concepts", [])) > 0
    has_facts = len(data.get("facts_and_data", [])) > 0
    return has_entities and has_facts

def postprocess_ingest(data):
    """
    Code-level quality control after LLM extraction.
    - Deduplicate entities/concepts and attach IDs
    - Remove entities with empty/missing descriptions
    """
    if not data:
        return data
    
    # 1. Basic lists (unchanged)
    data["key_points"] = [k for k in data.get("key_points", []) if isinstance(k, str)]
    data["facts_and_data"] = list(dict.fromkeys(
        f for f in data.get("facts_and_data", []) if isinstance(f, str) and f
    ))
    
    # 2. Summary fallback
    if not data.get("summary"):
        data["summary"] = " ".join(data["key_points"][:3]) if data["key_points"] else "(No summary extracted)"

    # 3. Nodes: attach id, then dedupe by id
    seen_ids = set()
    def attach_id_and_dedupe(nodes, type):
        unique = []
        for n in nodes:
            if not (isinstance(n, dict) and n.get("name") and n.get("overview")):
                continue
            nid = sanitize_filename(n["name"])
            if not nid or nid in seen_ids:
                continue
            n["id"] = nid  
            n["node_type"] = type 
            n["overview"] = n["overview"].strip()
            n["details"] = re.sub(r'\n+', '\n\n', n.get("details", "").strip())
            seen_ids.add(nid)
            unique.append(n)
        return unique
    
    data["entities"] = attach_id_and_dedupe(data.get("entities", []), "entity")
    data["concepts"] = attach_id_and_dedupe(data.get("concepts", []), "concept")
    
    # 4. Relationships: convert to (source_id, description, target_id) triples
    seen_rels = set()
    triples = []
    for r in data.get("relationships", []):
        if not (isinstance(r, dict) and r.get("source_name") and r.get("target_name")):
            continue
        sid = sanitize_filename(r["source_name"])
        tid = sanitize_filename(r["target_name"])
        desc = r.get("description", "")
        if not (sid and tid) or sid not in seen_ids or tid not in seen_ids:
            continue
        key = (sid, tid, desc)
        if key in seen_rels:
            continue
        seen_rels.add(key)
        triples.append((sid, desc, tid))
    data["relationships"] = triples

    return data

def build_related_block(node_id, source, relations):
    related_lines = [f"- [[{source}]] — source material"]
    for rel in relations:
        if rel[0] == node_id:
            related_lines.append(f"- [[{rel[2]}]] — {rel[1]}")
        elif rel[2] == node_id:
            related_lines.append(f"- [[{rel[0]}]] — {rel[1]}")
    related_block = "\n".join(related_lines)
    return related_block

# ══════════════════════════════════════════════════
#  Ingest document
# ══════════════════════════════════════════════════
def ingest_document(title, content):
    """Pass A: Extract structured data from raw document.
    No existing knowledge context — keeps input focused on the document."""
    prompt = INGEST_PROMPT.format(title=title, content=content)

    # First attempt
    raw_output, _ = call_llm(prompt, INGEST_TOKENS)
    _, data = strip_thinking(raw_output)
    data = parse_json_response(data)
    
    if data and is_complete_result(data):
        return postprocess_ingest(data)

    # Retry
    if data:
        print(f"    Result incomplete, retrying with maximum tokens...")
    else:
        print(f"    Parse failed, retrying with larger tokens...")
        
    raw_output, _ = call_llm(prompt, max_tokens=MAX_MODEL_TOKENS)
    _, data = strip_thinking(raw_output)
    data = parse_json_response(data, debug=True)
    return postprocess_ingest(data) if data else None

# ══════════════════════════════════════════════════
#  Reconcile with existing knowledge
# ══════════════════════════════════════════════════
def reconcile_with_existing(title, data, kg):
    """Pass B: Compare extracted data against existing wiki knowledge.
    Small context — only structured data, no raw document.
    Returns merge instructions and conflicts."""
    # 1. EXISTING context: id — name — overview
    existing_nodes = "\n".join(
        f"  {nid} — {node.get('name', '?')} — {node.get('overview', '')[:80]}"
        for nid, node in kg.nodes.items()
    )
    
    # 2. NEW summary: only id + name + overview, no internal noise
    new_data_summary = json.dumps({
        "entities": [
            {"id": e["id"], "name": e["name"], "overview": e.get("overview", "")[:80]}
            for e in data.get("entities", [])
        ],
        "concepts": [
            {"id": c["id"], "name": c["name"], "overview": c.get("overview", "")[:80]}
            for c in data.get("concepts", [])
        ],
    }, ensure_ascii=False)

    prompt = RECONCILE_PROMPT.format(
        existing_nodes=existing_nodes,
        title=title,
        new_data=new_data_summary,
    )

    raw_output, _ = call_llm(prompt, max_tokens=RECONCILE_TOKENS)
    _, result = strip_thinking(raw_output)
    result = parse_json_response(result, debug=False) or {}
    
    # 3. Build id rewrite map: new_id → existing_id (validated against both sides)
    new_ids = {n["id"] for n in data.get("entities", []) + data.get("concepts", [])}
    id_rename_map = {}
    for pair in result.get("merge_pairs", []):
        if not isinstance(pair, dict):
            continue
        new_id = pair.get("new_id")
        exist_id = pair.get("existing_id")
        if not (new_id and exist_id):
            continue
        if new_id not in new_ids or exist_id not in kg.nodes:
            continue
        id_rename_map[new_id] = exist_id
        print(f"    Merging: {new_id} → {exist_id}")
        
    # 4. Apply rewrite in-place: update id, and sync name to canonical
    if id_rename_map:
        for item in data.get("entities", []) + data.get("concepts", []):
            old_id = item["id"]
            if old_id in id_rename_map:
                new_id = id_rename_map[old_id]
                item["id"] = new_id
                item["name"] = kg.nodes[new_id].get("name", item["name"])
        data["relationships"] = [
            (id_rename_map.get(sid, sid), desc, id_rename_map.get(tid, tid))
            for (sid, desc, tid) in data["relationships"]
        ]
            
    # 5. Extract conflicts (use id; print uses fields that match the prompt)
    conflicts = [c for c in result.get("conflicts", []) if isinstance(c, dict)]
    for c in conflicts:
        print(f"    CONFLICT [{c.get('existing_id', '?')}]: "
              f"existing='{c.get('existing_overview', '')}' "
              f"vs new='{c.get('new_overview', '')}'")
        
    if not conflicts:
        print(f"    No conflicts detected with existing knowledge.")    
    return data, conflicts

# ══════════════════════════════════════════════════
#  Page Writers
# ══════════════════════════════════════════════════
def write_node_page(node, node_type, target_dir, source, relations):
    """Write or update node page"""
    node_id = node.get("id")
    filepath = target_dir / f"{node_id}.md"

    # ── Update ──
    if filepath.exists():
        # A. update frontmatter: add source if not present, update timestamp
        post = frontmatter.load(filepath)
        post['updated'] = TODAY
        sources = post.get('sources', [])
        if source not in sources:
            sources.append(source)
        post['sources'] = sources
        
        # B. update content: append new source + facts to existing content
        body = post.content
        head, _, rest = body.partition("## Details")
        details, _, related = rest.partition("## Related")
        
        head = head.rstrip() + (f"\n\n{node['overview']}\n\n")
        details = details.rstrip() + (f"\n\n{node['details']}\n\n")
        related = related.rstrip() + (f"\n{build_related_block(node_id, source, relations)}\n")
        post.content = f"{head}## Details{details}## Related{related}"

        filepath.write_text(frontmatter.dumps(post), encoding="utf-8")
        return node_id, 0
    
    # ── Create ──
    post = frontmatter.Post(
        content=(
            f"# {node['name']}\n\n"
            f"{node['overview']}\n\n"
            f"## Details\n\n"
            f"{node['details']}\n\n"
            f"## Related\n\n"
            f"{build_related_block(node_id, source, relations)}\n"
        ),
        title=node["name"],
        type=node_type,
        created=TODAY,
        updated=TODAY,
        tags=node.get("tags", []),
        sources=[source],
    )
    filepath.write_text(frontmatter.dumps(post), encoding="utf-8")
    return node_id, 1

def write_source_page(title, data, source_filename):
    """Write source summary page"""
    filepath = SOURCES_DIR / f"{title}.md"
    
    key_points_text = "\n".join(f"- {p}" for p in data.get("key_points", []))
    facts_text = "\n".join(f"- {f}" for f in data.get("facts_and_data", []))
    node_ids = [n["id"] for n in data.get("entities", []) + data.get("concepts", [])]
    related_lines = [f"- [[{rid}]]" for rid in node_ids] or ["(none yet)"]
    related_text = "\n".join(related_lines)

    post = frontmatter.Post(
        content=(
            f"# {title}\n\n"
            f"## Source Info\n\n"
            f"- **Raw file**: [{source_filename}](../../documents/{source_filename})\n"
            f"- **Type**: {data.get('document_type', 'other')}\n"
            f"- **Ingested**: {TODAY}\n\n"
            f"## Core Content\n\n"
            f"{data.get('summary', 'N/A')}\n\n"
            f"## Key Points\n\n"
            f"{key_points_text}\n\n"
            f"## Citations & Data\n\n"
            f"{facts_text}\n\n"
            f"## Related\n\n"
            f"{related_text}\n"
        ),
        title=title,
        type="source",
        created=TODAY,
        updated=TODAY,
        tags=data.get("document_tags", []),
        raw_file=f"documents/{source_filename}",
    )
    filepath.write_text(frontmatter.dumps(post), encoding="utf-8")

# ══════════════════════════════════════════════════
#  Linking existing pages 
# ══════════════════════════════════════════════════
def link_mentions_in_existing_pages(new_nodes):
    """
    Scan all existing wiki pages. If any existing page mentions a topic
    that now has a new page, add a [[wikilink]] backlink.
    """
    all_dirs = [SOURCES_DIR, ENTITIES_DIR, CONCEPTS_DIR]
    new_ids = [e["id"] for e in new_nodes]
    updated_count = 0

    for directory in all_dirs:
        if not directory.exists():
            continue
        for filepath in directory.glob("*.md"):
            if filepath.stem in new_ids:
                continue
            
            post = frontmatter.load(filepath)
            content = post.content
            
            new_links = []
            for node in new_nodes:
                node_id = node["id"]
                node_name = node["name"]
                if f"[[{node_id}]]" in content:
                    continue
                pattern = re.compile(rf'\b{re.escape(node_name)}\b', re.IGNORECASE)
                if pattern.search(content):
                    new_links.append(f"- [[{node_id}]] — mentioned in text")
                
            if new_links:
                if "## Related" in content:
                    parts = content.rsplit("## Related", 1)
                    content = parts[0] + "## Related" + parts[1].rstrip() + "\n" + "\n".join(new_links) + "\n"
                else:
                    content += "\n\n## Related\n\n" + "\n".join(new_links) + "\n"
                
                post.content = content
                post['updated'] = TODAY
                filepath.write_text(frontmatter.dumps(post), encoding="utf-8")
                updated_count += 1
                
    return updated_count

# ══════════════════════════════════════════════════
#  Index & Log Writers
# ══════════════════════════════════════════════════
def write_index(sources_info, all_new_nodes):
    """Write wiki/index.md — enriched with key facts for better LLM routing.
    The index is what the LLM reads at query time to decide which pages to
    retrieve. Richer descriptions = better routing = higher answer_in_context.
    """
    filepath = WIKI_DIR / "index.md"  
    if not filepath.exists():
        print(f"    WARNING: index.md not found, please init the wiki first")
        return
    
    post = frontmatter.load(filepath)
    post['updated'] = TODAY
    body = post.content
    
    sources, _, rest = body.partition("## Entities")
    sources_lines = [f"- [{s['title']}](sources/{s['title']}.md) — {s.get('summary', '')} ({TODAY})" for s in sources_info]
    sources = sources.rstrip() + "\n" + "\n".join(sources_lines) + "\n\n"
    
    entities, _, rest = rest.partition("## Concepts")
    entity_lines = [f"- [{n.get('id', '?')}](entities/{n['id']}.md) — {n.get('overview', '')}" for n in all_new_nodes if n["node_type"] == "entity"]
    entities = entities.rstrip() + "\n" + "\n".join(entity_lines) + "\n\n"
    
    concepts, _, analysis = rest.partition("## Analyses")
    concept_lines = [f"- [{n.get('id', '?')}](concepts/{n['id']}.md) — {n.get('overview', '')}" for n in all_new_nodes if n["node_type"] == "concept"]
    concepts = concepts.rstrip() + "\n" + "\n".join(concept_lines) + "\n\n"
    
    post.content = f"{sources}## Entities{entities}## Concepts{concepts}## Analyses{analysis}"
    filepath.write_text(frontmatter.dumps(post), encoding="utf-8")
     
def write_overview(stats):
    """Write wiki/overview.md"""
    filepath = WIKI_DIR / "overview.md"
    if not filepath.exists():
        print(f"    WARNING: overview.md not found, please init the wiki first")
        return
    
    post = frontmatter.load(filepath)
    post['updated'] = TODAY
    post.content=(
        f"# Knowledge Base Overview\n\n"
        f"- **Documents ingested**: {stats['num_docs']}\n"
        f"- **Source pages**: {stats['num_sources']}\n"
        f"- **Entity pages**: {stats['num_entities']}\n"
        f"- **Concept pages**: {stats['num_concepts']}\n"
        f"- **Knowledge graph nodes**: {stats['num_nodes']}\n"
        f"- **Knowledge graph edges**: {stats['num_edges']}\n"
        f"- **Last updated**: {TODAY}\n"
    )
    filepath.write_text(frontmatter.dumps(post), encoding="utf-8")
    
# ══════════════════════════════════════════════════
#  Main Ingest Flow (per ingest.md workflow)
# ══════════════════════════════════════════════════
def main():
    print(f"=== LLM Wiki Ingest ===")

    # --------------------------------------
    # Step 0: Verify LLM server is reachable and Wiki is initialized (index.md exists). 
    # These are prerequisites for the ingest to work at all.
    print("\nStep 0: Checking LLM connection...")
    check_llm_connection()
    print(f"    Connected to {LLM_MODEL}")
    
    # Verify wiki directory exists
    if not WIKI_DIR.exists() or not (WIKI_DIR / "index.md").exists():
        print(f"    WARNING: Wiki not initialized, running init_kb()...")
        init_kb(KB_DIR)
    print(f"    Wiki initialized at {WIKI_DIR}")
    
    # --------------------------------------
    # Step 1: Check what needs ingesting (skip already ingested)
    all_md_files = sorted(glob.glob(str(RAW_DIR / "*.md")))
    already_ingested = get_ingested_sources()
    pending = []
    for md in all_md_files:
        stem = Path(md).stem
        if stem not in already_ingested:
            pending.append(md)
            
    if not pending:
        print("No new documents found for ingest.")
        return
    print(f"\nStep 1: Found {len(all_md_files)} raw documents, {len(pending)} new to ingest")
    
    
    # --------------------------------------
    # Step 2: Load existing KG (incremental ingest preserves previous knowledge)
    if GRAPH_FILE.exists():
        with open(GRAPH_FILE, "r", encoding="utf-8") as f:
            kg = KnowledgeGraph(json.load(f))
        print(f"\nStep 2: Loaded existing KG: {len(kg.nodes)} nodes, {len(kg.edges)} edges")
    else:
        kg = KnowledgeGraph()
        print(f"\nStep 2: Starting with empty KG")
        
    # --------------------------------------
    # Step 3: Ingest each pending document
    print(f"\nStep 3: Starting ingest...")
    log_entries = []
    sources_info = []
    all_new_nodes = []
    total_time = 0

    for i, md_path in enumerate(pending):
        filename = Path(md_path).name
        file_id = Path(md_path).stem  # remove suffix like .md,
        title = file_id # for sources and raw file reference, we keep their filename as the Id to avoid confusion.
        with open(md_path, "r", encoding="utf-8") as f:
            content = f.read()
            
        print(f"\n    Ingesting ({i+1}/{len(pending)}): {title} ({len(content)} chars)...")
        t_start = time.time()

        # Pass A: Extract structured data from raw document
        data = ingest_document(title, content)
        if data is None:
            print(f"    WARNING: LLM extraction failed, using minimal fallback")
            data = {
                "summary": content[:500],
                "key_points": [],
                "facts_and_data": [],
                "entities": [],
                "concepts": [],
                "relationships": [],
            }

        # Pass B: Reconcile with existing knowledge (small, fast call)
        if kg.nodes and data.get("entities"):
            print(f"    Reconciling with existing nodes...")
            data, conflicts = reconcile_with_existing(title, data, kg)
        else:
            conflicts = []
            

        print("    Creating Source/Entity/Concept Pages and updating KG...")
        pages_created = [f"sources/{filename}"]
        pages_updated = []
        
        # A. Write source page first
        write_source_page(title, data, filename)
        
        # B. Then write entity and concept pages, while updating the KG
        for entity in data.get("entities", []):
            eid, is_new = write_node_page(entity, "entity", ENTITIES_DIR , title, data['relationships'])
            kg.add_node(eid, entity["name"], "entity", entity.get("overview", ""), source_doc=title)
            if is_new:
                pages_created.append(f"entities/{eid}.md")
                all_new_nodes.append(entity)
            else:
                pages_updated.append(f"entities/{eid}.md")
        for concept in data.get("concepts", []):
            cid, is_new = write_node_page(concept, "concept", CONCEPTS_DIR, title, data['relationships'])
            kg.add_node(cid, concept["name"], "concept", concept.get("overview", ""), source_doc=title)
            if is_new:
                pages_created.append(f"concepts/{cid}.md")
                all_new_nodes.append(concept)
            else:
                pages_updated.append(f"concepts/{cid}.md")
        
        # C. Add edges to KG
        for sid, desc, tid in data.get("relationships", []):
            kg.add_edge(sid, tid, desc, source_doc=title)
                
        # D. Log details and collect source info for index
        t_end = time.time()
        elapsed = t_end - t_start
        total_time += elapsed
        
        log_entries.append({
            "date": TODAY,
            "action": "ingest",
            "title": title,
            "details": [
                f"Pages created: {', '.join(pages_created)}",
                f"Pages updated: {', '.join(pages_updated) if pages_updated else 'none'}",
                f"Conflicts: {', '.join(c.get('existing_id', '') for c in conflicts) if conflicts else 'none'}",
            ]
        }) 
        sources_info.append({
            "title": title,
            "summary": data.get("summary", "")
        })
        
        n_facts = len(data.get("facts_and_data", []))
        n_ent = len(data.get("entities", []))
        n_con = len(data.get("concepts", []))
        n_rel = len(data.get("relationships", []))
        print(f"    Done: {n_facts} facts, {n_ent} entities, {n_con} concepts, "
              f"{n_rel} relations ({elapsed:.1f}s)")
        
        
    # --------------------------------------
    # Step 4: link mentions in existing_pages
    if all_new_nodes:
        print(f"\nStep 4: Ensuring existing pages link to new pages...")
        backlinks_added = link_mentions_in_existing_pages(all_new_nodes)
        print(f"  Added backlinks to {backlinks_added} existing pages")

    # --------------------------------------
    # Step 5: Write index, log, overview and save KG
    print(f"\nStep 5: Writing index.md, log.md, overview.md...")
    graph_dict = kg.to_dict()
    kg.save()
    write_index(sources_info, all_new_nodes)
    
    # Update log
    log_entry = [f"## [{entry['date']}] {entry['action']} | {entry['title']}\n" + "\n".join(f"- {d}" for d in entry.get("details", [])) for entry in log_entries]
    log_entry = "\n\n".join(list(reversed(log_entry)))
    update_log(log_entry)
    # Update overview
    write_overview({
        "num_docs": len(all_md_files),
        "num_sources": len(sources_info),
        "num_entities": graph_dict["stats"]["num_entities"],
        "num_concepts": graph_dict["stats"]["num_concepts"],
        "num_nodes": graph_dict["stats"]["num_nodes"],
        "num_edges": graph_dict["stats"]["num_edges"],
    })

    # --------------------------------------
    # --------------------------------------
    # Final report
    print(f"\n{'='*50}")
    print(f"  Wiki Ingest Complete!")
    print(f"{'='*50}")
    print(f"  Wiki directory:    {WIKI_DIR}")
    print(f"  Total documents:   {len(all_md_files)}")
    print(f"  Newly ingested:    {len(pending)}")
    print(f"  Source pages:      {len(sources_info)}")
    print(f"  Entity pages:      {graph_dict['stats']['num_entities']}")
    print(f"  Concept pages:     {graph_dict['stats']['num_concepts']}")
    print(f"  Graph nodes:       {graph_dict['stats']['num_nodes']}")
    print(f"  Graph edges:       {graph_dict['stats']['num_edges']}")
    print(f"  Total time:        {total_time:.1f}s")
    if total_time > 0 and len(pending) > 0:
        print(f"  Avg per document:  {total_time/len(pending):.1f}s")

if __name__ == "__main__":
    main()
