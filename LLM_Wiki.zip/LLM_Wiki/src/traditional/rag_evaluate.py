"""
Traditional RAG evaluation script (batch BERTScore version)
Process: question → bge-m3 encoding → Milvus retrieval top-3 → LLM generate answer → compare ground truth
Support vLLM local deployment (OpenAI compatible API)
"""

import json
import time
import re
import string
import argparse
from FlagEmbedding import BGEM3FlagModel
from pymilvus import MilvusClient
from tqdm import tqdm

from rouge_score import rouge_scorer
from bert_score import score as bert_score_fn

from src.utils.config import (
    DATA_DIR_NAME, MODEL_TAG, OUTPUT_DIR, DB_FILE, QA_FILE,
    EMB_MODEL_NAME, COLLECTION_NAME, TOP_K,
    LLM_MODEL, ENABLE_THINKING, QUERY_TOKENS,
    BATCH_SIZE,
)
from src.utils.prompt import RAG_PROMPT
from src.utils.helper import call_llm, strip_thinking

# ── Evaluation Metrics ──
rouge = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)

def normalize_answer(s):
    s = s.lower()
    s = "".join(ch for ch in s if ch not in set(string.punctuation))
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    s = " ".join(s.split())
    return s

def exact_match(prediction, ground_truths):
    pred_norm = normalize_answer(prediction)
    return any(normalize_answer(gt) == pred_norm for gt in ground_truths)

def evaluate_rouge(prediction, ground_truths):
    scores = [rouge.score(gt, prediction)['rougeL'].fmeasure for gt in ground_truths]
    return max(scores)


def compute_retrieval_recall(qa, retrieved_ids, retrieved_titles):
    """Dual-mode retrieval recall.

    SQuAD-style (qa has 'chunk_id'): boolean hit — is the gold chunk in top-K?
    MultiHop-style (qa has 'evidence_titles', no chunk_id): fractional recall —
        |retrieved_titles ∩ evidence_titles| / |evidence_titles|.
        This reflects how much of the multi-doc evidence the retriever covered.

    Returns:
        (recall_value, gold_label) where recall_value is in [0.0, 1.0] and
        gold_label is the value to record in the per-question result.
    """
    # MultiHop: no single gold chunk; use evidence-title coverage.
    if "chunk_id" not in qa:
        gold_titles = qa.get("evidence_titles") or []
        if not gold_titles:
            return 0.0, None
        gold_set = set(gold_titles)
        hit_set = gold_set.intersection(retrieved_titles)
        return len(hit_set) / len(gold_set), sorted(gold_set)

    # SQuAD: boolean — was the gold chunk_id retrieved?
    gold_id = qa["chunk_id"]
    hit = str(gold_id) in [str(rid) for rid in retrieved_ids]
    return float(hit), gold_id


# ── Main ──
def main():
    parser = argparse.ArgumentParser(description="RAG Batch Evaluation")
    parser.add_argument("--debug", action="store_true",
                        help="Enable debug mode (only first 5 questions, no writeback)")
    args = parser.parse_args()
    
    # ── Initialization ──
    print("Loading embedding model and Milvus client...")
    emb_model = BGEM3FlagModel(EMB_MODEL_NAME, use_fp16=True)
    client = MilvusClient(str(DB_FILE))

    # -─ Load QA Pairs ──
    with open(QA_FILE, "r", encoding="utf-8") as f:
        qa_pairs = json.load(f)
    print(f"In total {len(qa_pairs)} question-answer pairs to evaluate.")
    
    if args.debug:
        print(">>> Running in DEBUG mode: only first 5 questions, no writeback")
        qa_pairs = qa_pairs[:5]

    # ── Main Loop ──
    results = []
    total_em = 0
    total_rouge_l = 0.0
    total_bert_f1 = 0.0
    total_latency = 0.0
    total_tokens = 0
    total_recall = 0.0
    
    pbar = tqdm(qa_pairs, desc="Evaluating", unit="q",
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}] EM={postfix[0]:.2%} ROUGE-L={postfix[1]:.2%}",
                postfix=[0.0, 0.0])
    for i, qa in enumerate(qa_pairs):
        question = qa["question"]
        ground_truths = qa["answers"]["text"]

        t_start = time.time()
        
        # Retrieve relevant chunks using BGE-M3 embeddings and Milvus.
        # We pull `title` alongside `text` so we can compute evidence-title
        # recall for MultiHop-RAG-style QA where there's no single gold chunk.
        q_emb = emb_model.encode([question], max_length=1024)["dense_vecs"][0].tolist()
        search_results = client.search(
            collection_name=COLLECTION_NAME,
            data=[q_emb],
            limit=TOP_K,
            output_fields=["text", "title"],
        )
        retrieved_chunks = [hit["entity"]["text"] for hit in search_results[0]]
        retrieved_ids = [hit["id"] for hit in search_results[0]]
        retrieved_titles = {hit["entity"].get("title", "") for hit in search_results[0]}
        retrieved_titles.discard("")
        context = "\n\n".join(retrieved_chunks)
        
        # Generate answer with LLM
        prompt = RAG_PROMPT.format(context=context, question=question)
        raw, tokens = call_llm(prompt, max_tokens=QUERY_TOKENS)
        if raw:
            _, answer = strip_thinking(raw)
        else:
            answer, tokens = "", 0
        t_end = time.time()
        latency = t_end - t_start
        
        answer = answer if answer else "empty"
        em = exact_match(answer, ground_truths)
        rouge_l = evaluate_rouge(answer, ground_truths)
        retrieval_hit, gold_label = compute_retrieval_recall(qa, retrieved_ids, retrieved_titles)

        result = {
            "qa_id": qa["qa_id"],
            "question": question,
            "ground_truths": ground_truths,
            "predicted": answer,
            "exact_match": em,
            "rouge_l": rouge_l,
            "bert_f1": 0.0,
            "latency": round(latency, 3),
            "tokens": tokens,
            "retrieved_chunk_ids": retrieved_ids,
            "retrieved_titles": sorted(retrieved_titles),
            # For SQuAD this is the gold chunk_id; for MultiHop the gold title list.
            "gold": gold_label,
            "retrieval_hit": retrieval_hit,
        }
        results.append(result)
        total_em += em
        total_rouge_l += rouge_l
        total_latency += latency
        total_tokens += tokens
        total_recall += retrieval_hit
        
        pbar.update(1)
        pbar.postfix[0] = total_em / pbar.n
        pbar.postfix[1] = total_rouge_l / pbar.n
        
        if (i + 1) % BATCH_SIZE == 0 or (i + 1) == len(qa_pairs):
            print(f"\n     Computing BERTScore for batch {(i + 1) // BATCH_SIZE}...")
            batch_start_idx = len(results) - (i % BATCH_SIZE) - 1
            batch_preds = [res["predicted"] for res in results[batch_start_idx:]]
            batch_refs = [res["ground_truths"][0] for res in results[batch_start_idx:]]
            _, _, batch_bert_tensor = bert_score_fn(
                batch_preds, batch_refs, lang="en", verbose=False,
            )
            for j in range(len(batch_preds)):
                results[batch_start_idx + j]["bert_f1"] = batch_bert_tensor[j].item()
                total_bert_f1 += batch_bert_tensor[j].item()
                
    # ── Final Metrics and Output ──
    n = len(qa_pairs)
    # MultiHop QA carries no `chunk_id`; we report evidence-title coverage instead.
    recall_mode = "chunk_id_hit" if "chunk_id" in qa_pairs[0] else "evidence_title_coverage"
    summary = {
        "model": LLM_MODEL,
        "method": "traditional_rag",
        "num_questions": n,
        "exact_match": round(total_em / n, 4),
        "rouge_l": round(total_rouge_l / n, 4),
        "bert_f1": round(total_bert_f1 / n, 4),
        "avg_latency_s": round(total_latency / n, 3),
        "avg_tokens": round(total_tokens / n, 1),
        "top_k": TOP_K,
        "retrieval_recall": round(total_recall / n, 4),
        "retrieval_recall_mode": recall_mode,
    }
    output = {"summary": summary, "results": results}
    data_match = re.search(r'([^/]+)(?=_data)', DATA_DIR_NAME)
    short_data_name = data_match.group(1) if data_match else "dataset"
    if ENABLE_THINKING:
        output_file = OUTPUT_DIR / f"{MODEL_TAG}_{short_data_name}_rag_thinking_results.json"
    else:
        output_file = OUTPUT_DIR / f"{MODEL_TAG}_{short_data_name}_rag_results.json"

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    # Print report
    print(f"\n{'='*50}")
    print(f"📊 RAG Evaluation Results")
    print(f"{'='*50}")
    print(f"  Model:             {LLM_MODEL}")
    print(f"  Exact Match:       {summary['exact_match']:.2%}")
    print(f"  Rouge-L:           {summary['rouge_l']:.2%}")
    print(f"  BERT-F1:           {summary['bert_f1']:.2%}")
    print(f"  Avg Latency:       {summary['avg_latency_s']:.3f}s")
    print(f"  Avg Tokens:        {summary['avg_tokens']}")
    print(f"  Retrieval Top-{TOP_K} Recall: {summary['retrieval_recall']:.2%} ({recall_mode})")
    print(f"\nOutput File: {output_file}")

if __name__ == "__main__":
    main()