"""
Import chunks_with_embeddings.json to Milvus.

Stores `text` AND `title` so evaluate can compute evidence-title recall
for MultiHop-RAG-style data (no single gold chunk per question).
pip install "pymilvus[lite]"
"""

import json
from pymilvus import MilvusClient

from src.utils.config import (
    CHUNKS_FILE, DB_FILE,
    COLLECTION_NAME, EMB_DIM,
)

# ── Load Data ──
with open(str(CHUNKS_FILE), "r", encoding="utf-8") as f:
    chunks = json.load(f)

print(f"Loaded {len(chunks)} chunks")

# ── Initialize Milvus Lite ──
client = MilvusClient(str(DB_FILE))
# If collection already exists, drop and recreate
if client.has_collection(COLLECTION_NAME):
    client.drop_collection(COLLECTION_NAME)

# enable_dynamic_field lets us attach arbitrary scalar fields (text, title)
# alongside the dense vector without declaring a strict schema.
client.create_collection(
    collection_name=COLLECTION_NAME,
    dimension=EMB_DIM,
    id_type="int",
    metric_type="COSINE",
    enable_dynamic_field=True,
)

# ── Insert Data ──
data = [
    {
        "id": c["chunk_id"],
        "vector": c["embedding"],
        "text": c["text"],
        "title": c.get("title", ""),
    }
    for c in chunks
]

client.insert(collection_name=COLLECTION_NAME, data=data)

print(f"✅ Insertion completed!")
print(f"    Collection: {COLLECTION_NAME}")
print(f"    Data count: {len(data)}")
print(f"    Storage: {DB_FILE}")
