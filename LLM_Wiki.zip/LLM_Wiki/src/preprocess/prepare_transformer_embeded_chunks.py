"""
Generate embedding for each chunk in chunks.json, using BAAI/bge-m3
Output: chunks_with_embeddings.json
"""

import json
from FlagEmbedding import BGEM3FlagModel

from src.utils.config import ROOT, EMB_MODEL_NAME, BATCH_SIZE

# ── Check data configuration and directory ──
dataset_name = "squad_data" # or "multihop_rag_data"
# dataset_name = "multihop_rag_data"

CHUNKS_FILE = ROOT / f"data/{dataset_name}/chunks.json"
OUTPUT_FILE = ROOT / f"data/{dataset_name}/chunks_with_embeddings.json"

# ── Load chunks ──
with open(CHUNKS_FILE, "r", encoding="utf-8") as f:
    chunks = json.load(f)
    
texts = [c["text"] for c in chunks]
print(f"In total {len(texts)} chunks, starting to generate embeddings...")

# ── Load model & encode ──
model = BGEM3FlagModel(EMB_MODEL_NAME, use_fp16=True)
embeddings = model.encode(texts, batch_size=BATCH_SIZE, max_length=1024)["dense_vecs"]

# ── Write back ──
for chunk, emb in zip(chunks, embeddings):
    chunk["embedding"] = emb.tolist()
with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(chunks, f, ensure_ascii=False)
    
print(f"\n{'='*50}")
print(f"Embedding {dataset_name} chunks complete!")
print(f" Completed! Output: {OUTPUT_FILE}")
print(f" embedding dimensions: {len(chunks[0]['embedding'])}")
print(f"\n{'='*50}")
