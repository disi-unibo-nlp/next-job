"""
Prepare the MultiHop-RAG dataset (yixuantt/MultiHopRAG)
The output format is consistent with squad_demo_data:
  multihop_rag_data/
    documents/ *.md (one file per article)
    chunks.json (chunked text, with embedding placeholder)
    qa_pairs.json (question and answer pairs, referenced with chunk_id)
"""
import json
import re
import os
from pathlib import Path
from collections import Counter, defaultdict
from datasets import load_dataset

from src.utils.config import ROOT, DATA_DOC_NUM, CHUNK_SIZE
from src.utils.helper import sanitize_filename

# ── Check data configuration and directory ──
NUM_TITLES = DATA_DOC_NUM
CHUNK_SIZE = CHUNK_SIZE  # Target word count per chunk
OUTPUT_DIR = ROOT / "data/multihop_rag_data"
DOCS_DIR = OUTPUT_DIR / "documents"
QA_FILE = OUTPUT_DIR / "qa_pairs.json"
CHUNKS_FILE = OUTPUT_DIR / "chunks.json"
os.makedirs(DOCS_DIR, exist_ok=True)


# ── Load Data from Hugging Face ──
print("Downloading MultiHop-RAG from Hugging Face...")
queries = load_dataset("yixuantt/MultiHopRAG", "MultiHopRAG", split="train")
corpus = load_dataset("yixuantt/MultiHopRAG", "corpus", split="train")
print(f"Loaded {len(queries)} queries and {len(corpus)} corpus rows")


# ── Select documents ──
# 1. Extract evidence titles from each query
def get_evidence_titles(q):
    """Flatten and extract valid evidence titles from a query."""
    titles = [
        ev if isinstance(ev, str) else ev.get("title") or ev.get("source")
        for ev in q.get("evidence_list", [])
    ]
    return [t for t in titles if t]
valid_queries = [q for q in queries if q.get("question_type") != "null_query"]
query_to_docs = {
    i: set(get_evidence_titles(q)) 
    for i, q in enumerate(valid_queries) if get_evidence_titles(q)
}
# 2. Count document references and select top-N
doc_counts = Counter(title for docs in query_to_docs.values() for title in docs)
selected_titles = [title for title, _ in doc_counts.most_common(NUM_TITLES)]
selected_title_set = set(selected_titles)

# 3. Keep only queries where ALL evidence is within our selected top documents
selected_query_indices = [
    q_idx for q_idx, docs in query_to_docs.items() if docs.issubset(selected_title_set)
]
print(f"Selected top-{NUM_TITLES} docs. Complete QA pairs: {len(selected_query_indices)}")


# ── Process Data ──
# 1.Get selected document texts from corpus, grouped by title. Also keep metadata (source, url).
title_to_texts = defaultdict(list)
title_to_meta = {}
for row in corpus:
    title = row.get("title", "")
    if title in selected_title_set:
        body = row.get("body", "")
        if body:
            title_to_texts[title].append(body)
        if title not in title_to_meta:
            title_to_meta[title] = {"source": row.get("source", ""), "url": row.get("url", "")}

# 2. Build Markdown Files & Chunks
chunks = []
title_to_chunk_ids = defaultdict(list)
title_to_doc_id = {title: i for i, title in enumerate(selected_titles)}
chunk_id = 0

for title in selected_titles:
    full_text = "\n\n".join(title_to_texts[title])
    meta = title_to_meta.get(title, {})
    doc_id = title_to_doc_id[title]
    filename = f"{sanitize_filename(title)}.md"
    path = Path(DOCS_DIR) / filename

    # a. Write Markdown Document
    md_content = f"# {title}\n\n**Source:** {meta.get('source', '')}\n**URL:** {meta.get('url', '')}\n---\n\n{full_text}"
    path.write_text(md_content, encoding="utf-8")
    print(f"Wrote {path.name}: {len(full_text):,} chars")

    # b. Chunking (Sliding Window)
    current_chunk, current_words = [], 0
    # Use a generator to yield clean paragraphs and avoid keeping a large intermediate list
    for para in (p.strip() for p in full_text.split("\n") if p.strip()):
        words = len(para.split())
        if current_chunk and current_words + words > CHUNK_SIZE:
            chunks.append({"chunk_id": chunk_id, "doc_id": doc_id, "title": title, "text": "\n".join(current_chunk)})
            title_to_chunk_ids[title].append(chunk_id)
            chunk_id += 1
            current_chunk, current_words = [], 0
        
        current_chunk.append(para)
        current_words += words
        
    if current_chunk:
        chunks.append({"chunk_id": chunk_id, 
                       "doc_id": doc_id, 
                       "title": title, 
                       "text": "\n".join(current_chunk)})
        title_to_chunk_ids[title].append(chunk_id)
        chunk_id += 1
CHUNKS_FILE.write_text(json.dumps(chunks, ensure_ascii=False, indent=2), encoding="utf-8")
        
# 3. Build QA Pairs
qa_pairs = []
for q_idx in selected_query_indices:
    q = valid_queries[q_idx]
    ev_titles = get_evidence_titles(q)
    
    qa_pairs.append({
        "qa_id": f"mhop_{q_idx}",
        "title": " | ".join(dict.fromkeys(ev_titles)), # Preserves order, removes duplicates
        "question": q["query"],
        "answers": {"text": [q.get("answer", "")]},
        "evidence_titles": ev_titles,
        "question_type": q.get("question_type", "")
    })
QA_FILE.write_text(json.dumps(qa_pairs, ensure_ascii=False, indent=2), encoding="utf-8")


# ── Summary ──
print(f"\n{'='*50}")
print(f"MultiHop-RAG data preparation complete!")
print(f"{'='*50}")
print(f"  Directory: {OUTPUT_DIR}")
print(f"  Documents: {len(selected_titles)} articles")
print(f"  Chunks: {len(chunks)} chunks")
print(f"  QA pairs: {len(qa_pairs)} question-answer pairs")
print(f"\n{'='*50}")
