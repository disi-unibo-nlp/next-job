"""
SQuAD v2 data preparation script
- Select NUM_TITLES titles from the validation set
- Generate qa_pairs.json (question + answer + associated chunk_id)
- Each title generates a .md file (joined by unique context chunks)
"""

import json
import os
import re
from pathlib import Path
from collections import defaultdict
from datasets import load_dataset

from src.utils.config import ROOT, DATA_DOC_NUM
from src.utils.helper import sanitize_filename

# ── Check data configuration and directory ──
NUM_TITLES = DATA_DOC_NUM
OUTPUT_DIR = ROOT / "data/squad_data"
DOCS_DIR = OUTPUT_DIR / "documents"
QA_FILE = OUTPUT_DIR / "qa_pairs.json"
CHUNKS_FILE = OUTPUT_DIR / "chunks.json"
os.makedirs(DOCS_DIR, exist_ok=True)

# ── Load Data from Hugging Face ──
print("Downloading SQuAD v2 validation set from Hugging Face...")
validation_ds = load_dataset("rajpurkar/squad_v2", split="validation")
print(f"Loaded validation set with {len(validation_ds)} samples")

# ──  Select a subset of titles by referring NUM_TITLES and remove unanswerable questions ──
selected_titles = list(dict.fromkeys(validation_ds["title"]))[:NUM_TITLES]
selected_title_set = set(selected_titles)
filtered = validation_ds.filter(
    lambda x: x["title"] in selected_title_set and bool(x["answers"]["text"])
)
print(f"Selected {NUM_TITLES} titles. Total answerable samples: {len(filtered)}")


# ── Process Data ──
# 1. Process QA Pairs
title_chunks = defaultdict(list)
chunk_id_map = {}
qa_pairs = []
for row in filtered:
    title, context = row["title"].replace("_", " "), row["context"]
    if context not in chunk_id_map:
        chunk_id_map[context] = len(chunk_id_map)
        title_chunks[title].append((chunk_id_map[context], context))

    qa_pairs.append({
        "qa_id": row["id"],
        "title": title,
        "question": row["question"],
        "answers": {"text": row["answers"]["text"]},
        "chunk_id": chunk_id_map[context],
    })
QA_FILE.write_text(json.dumps(qa_pairs, ensure_ascii=False, indent=2), encoding="utf-8")
    
# 2. Process  Write Markdown Files and Chunks
title_to_doc_id = {title.replace("_", " "): i for i, title in enumerate(selected_titles)}
for title, chunk_list in title_chunks.items():
    full_text = "\n\n".join(ctx for _, ctx in chunk_list)
    doc_id = title_to_doc_id[title]
    filename = f"{sanitize_filename(title)}.md"
    path = DOCS_DIR / filename
    
    # a. Write Markdown Document
    md_content = f"# {title}\n\n---\n\n{full_text}"
    path.write_text(md_content, encoding="utf-8")
    print(f"  Wrote {path.name}: {len(full_text):,} chars")
    
# b. Chunking
chunks = [
    {"chunk_id": c_id, 
     "doc_id": title_to_doc_id[title], 
     "title": title, 
     "text": ctx}
    for title, chunks_list in title_chunks.items()
    for c_id, ctx in chunks_list
]
CHUNKS_FILE.write_text(json.dumps(chunks, ensure_ascii=False, indent=2), encoding="utf-8")
    

    
# ── Summary ──
print(f"\n{'='*50}")
print(f"SQuAD data preparation complete!")
print(f"{'='*50}")
print(f"  Directory: {OUTPUT_DIR}")
print(f"  Documents: {len(selected_titles)} articles")
print(f"  Chunks: {len(chunks)} chunks")
print(f"  QA pairs: {len(qa_pairs)} question-answer pairs")
print(f"\n{'='*50}")
