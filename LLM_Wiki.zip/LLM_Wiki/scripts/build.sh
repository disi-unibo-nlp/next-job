#!/bin/bash
# Build the Docker image
echo "Building llm-wiki Docker image..."
docker build -t llm-wiki:latest .
echo "Done! Image: llm-wiki:latest"
