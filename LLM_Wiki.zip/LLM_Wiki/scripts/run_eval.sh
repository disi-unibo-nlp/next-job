#!/bin/bash
# ═══════════════════════════════════════════════════════
#  LLM Wiki Evaluation — runs INSIDE Docker container
#  Starts vLLM server → runs eval on specified dataset
#
#  Env vars:
#    LLM_MODEL        - model name used by Python code for API calls
#    VLLM_MODEL       - HF repo to load
#    VLLM_TOKENIZER   - tokenizer repo (optional, for GGUF models)
#    ENABLE_THINKING  - "true" to enable thinking mode
#    GGUF_FILENAME    - specific .gguf file to load (optional)
#    NGPU             - tensor parallel size
#    MAX_MODEL_LEN    - context window
#    PORT             - vLLM server port (default 8000)
#    COMPANION_DEVICE - "cuda" or "cpu" for bge-m3 / BERTScore
#    EVAL_DATASET     - "squad" (default), "multihop", or "all"
# ═══════════════════════════════════════════════════════
set -e

LLM_MODEL="${LLM_MODEL:?ERROR: LLM_MODEL not set}"
VLLM_MODEL="${VLLM_MODEL:-${LLM_MODEL}}"
ENABLE_THINKING="${ENABLE_THINKING:-false}"
VLLM_TOKENIZER="${VLLM_TOKENIZER:-}"
GGUF_FILENAME="${GGUF_FILENAME:-}"
NGPU="${NGPU:-1}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-8192}"
PORT="${PORT:-8000}"
MODEL_TAG="${MODEL_TAG:-model}"
COMPANION_DEVICE="${COMPANION_DEVICE:-cuda}"
EVAL_DATASET="${EVAL_DATASET:-squad}"

echo "╔══════════════════════════════════════════════╗"
echo "║  LLM Wiki Evaluation Pipeline                ║"
echo "╠══════════════════════════════════════════════╣"
echo "║  LLM_MODEL:     ${LLM_MODEL} (${MODEL_TAG})"
echo "║  VLLM_MODEL:    ${VLLM_MODEL}"
echo "║  ENABLE_THINKING: ${ENABLE_THINKING}"
echo "║  GGUF_FILENAME: ${GGUF_FILENAME:-none}"
echo "║  GPUs:          ${NGPU}"
echo "║  MaxLen:        ${MAX_MODEL_LEN}"
echo "║  Port:          ${PORT}"
echo "║  Companions:    ${COMPANION_DEVICE}"
echo "║  Dataset:       ${EVAL_DATASET}"
echo "╚══════════════════════════════════════════════╝"

# ── 1. Build vLLM launch command ──
VLLM_ARGS=(
    --model "${VLLM_MODEL}"
    --served-model-name "${LLM_MODEL}"
    --tensor-parallel-size "${NGPU}"
    --max-model-len "${MAX_MODEL_LEN}"
    --max-num-seqs 24
    --trust-remote-code
    --port "${PORT}"
    --enable-prefix-caching
    --kv-cache-dtype fp8
    --gpu-memory-utilization 0.80
)

if [ -n "${VLLM_TOKENIZER}" ]; then
    VLLM_ARGS+=(--tokenizer "${VLLM_TOKENIZER}")
fi

if [ -n "${GGUF_FILENAME}" ]; then
    VLLM_ARGS+=(--gguf-filename "${GGUF_FILENAME}")
    VLLM_ARGS+=(--enforce-eager)
fi

echo ""
echo ">>> Starting vLLM server..."
echo "    Command: python3 -m vllm.entrypoints.openai.api_server ${VLLM_ARGS[*]}"
python3 -m vllm.entrypoints.openai.api_server "${VLLM_ARGS[@]}" \
    > /tmp/vllm.log 2>&1 &
VLLM_PID=$!

echo "    Waiting for vLLM to be ready (up to 30 min for large models)..."
for i in $(seq 1 360); do
    if curl -s http://localhost:${PORT}/health > /dev/null 2>&1; then
        echo "    vLLM ready! (took ~$((i*5))s)"
        break
    fi
    if ! kill -0 $VLLM_PID 2>/dev/null; then
        echo "    ERROR: vLLM process died. Log:"
        tail -80 /tmp/vllm.log
        exit 1
    fi
    sleep 5
done

if ! curl -s http://localhost:${PORT}/health > /dev/null 2>&1; then
    echo "    ERROR: vLLM did not start in time. Log:"
    tail -80 /tmp/vllm.log
    kill $VLLM_PID 2>/dev/null
    exit 1
fi

echo "    Checking served models..."
curl -s http://localhost:${PORT}/v1/models | python3 -m json.tool || true

# ═══════════════════════════════════════════════════════
#  Helper: run one dataset (wiki + RAG)
#  $5 = "skip_ingest" to reuse existing wiki (eval only)
# ═══════════════════════════════════════════════════════
run_dataset() {
    local DATA_DIR="$1"
    local DISPLAY_NAME="$2"
    local ENABLE_THINKING="$3"

    echo ""
    echo "╔══════════════════════════════════════════════╗"
    echo "║  Dataset: ${DISPLAY_NAME}"
    echo "║  Dir:     ${DATA_DIR}"
    echo "║  Thinking: ${ENABLE_THINKING}"
    echo "╚══════════════════════════════════════════════╝"

    export DATA_DIR="${DATA_DIR}"
    export LLM_MODEL="${LLM_MODEL}"
    export LLM_PORT="${PORT}"
    export ENABLE_THINKING="${ENABLE_THINKING}"
    export MODEL_TAG="${MODEL_TAG}"

    # ── Wiki Pipeline ──
    cd /workdir

    echo ""
    echo ">>> [Wiki/${DISPLAY_NAME}] Initializing fresh wiki..."
    rm -rf "/workdir/${DATA_DIR}/wiki"
    python3 -m src.wiki.init

    echo ">>> [Wiki/${DISPLAY_NAME}] Ingesting documents..."
    python3 -m src.wiki.ingest

    echo ">>> [Wiki/${DISPLAY_NAME}] Running evaluation..."
    python3 -m src.wiki.evaluate

    # ── RAG Pipeline ──
    echo ""
    echo ">>> [RAG/${DISPLAY_NAME}] Inserting chunks into Milvus..."
    cd /workdir/src/traditional
    python3 -m src.traditional.insert_milvus

    echo ">>> [RAG/${DISPLAY_NAME}] Running evaluation..."
    python3 -m src.traditional.rag_evaluate

    echo ""
    echo ">>> ${DISPLAY_NAME} complete!"
}

# ═══════════════════════════════════════════════════════
#  2. Run requested dataset(s)
# ═══════════════════════════════════════════════════════
case "${EVAL_DATASET}" in
    squad)
        run_dataset "data/squad_data" "SQuAD" "${ENABLE_THINKING}"
        ;;
    multihop|multiple)
        run_dataset "data/multihop_rag_data" "MultiHopRAG" "${ENABLE_THINKING}"
        ;;
    all)
        run_dataset "data/squad_data" "SQuAD" "${ENABLE_THINKING}"
        run_dataset "data/multihop_rag_data" "MultiHopRAG" "${ENABLE_THINKING}"
        ;;
    *)
        echo "ERROR: Unknown EVAL_DATASET='${EVAL_DATASET}'. Use: squad, multihop, all"
        exit 1
        ;;
esac

# ── Cleanup ──
kill $VLLM_PID 2>/dev/null
wait $VLLM_PID 2>/dev/null

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  Done! Results in /workdir/outputs/          ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
