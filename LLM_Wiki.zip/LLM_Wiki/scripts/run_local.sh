#!/bin/bash
# ═══════════════════════════════════════════════════════
#  Run evaluation  — single GPU
#  Direct Docker execution on RTX PRO 6000 (96GB)
#
#  Usage:
#    ./scripts/run_local.sh              # run all 3 models sequentially
#    ./scripts/run_local.sh 1            # Qwen3.5-27B (FP16)
#    ./scripts/run_local.sh 2            # Qwen3.5-122B-A10B (GPTQ-Int4)
#    ./scripts/run_local.sh 3            # Qwen3.5-35B-A3B (FP8)
#    ./scripts/run_local.sh 1 squad      # SQuAD only
#    ./scripts/run_local.sh 2 multihop   # MultiHop-RAG only
#    ./scripts/run_local.sh 3 all        # both sequentially
#    (optional thinking) 
#    ./scripts/run_local.sh 1 all true
#
#  Each run: download model → run eval → cleanup cache
#  Wiki is automatically rebuilt fresh for each model.
#
#  Before first run: ./scripts/build.sh
# ═══════════════════════════════════════════════════════

set -e
mkdir -p logs outputs

# ── Cleanup function: delete HF model cache to free disk ──
cleanup_model_cache() {
    echo ""
    echo ">>> Cleaning up model cache to free disk space..."
    local CACHE_DIR=".cache/huggingface/hub"
    if [ -d "${CACHE_DIR}" ]; then
        # List what we're deleting
        du -sh "${CACHE_DIR}" 2>/dev/null || true
        rm -rf "${CACHE_DIR}"
        echo "    Cache cleared: ${CACHE_DIR}"
    fi
    echo ""
}

# ── Core: run one model evaluation ──
run_model() {
    local LLM_MODEL="$1"
    local EVAL_DATASET="${2:-all}"
    local ENABLE_THINKING="${3:-false}"

    local MAX_MODEL_LEN="$4"
    local PORT="${5:-8000}"
    local MODEL_TAG=$(echo "${LLM_MODEL}" | grep -oE '[0-9]+(\.[0-9]+)?[BM]' | head -1)
    local MODEL_TAG="${MODEL_TAG:-model}"
    export MODEL_TAG

    echo ""
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║  Model: ${LLM_MODEL} (${MODEL_TAG})"
    echo "║  Context: ${MAX_MODEL_LEN} tokens"
    echo "║  Thinking mode: ${ENABLE_THINKING}"
    echo "║  Dataset: ${EVAL_DATASET}"
    echo "║  Port: ${PORT}"
    echo "╚══════════════════════════════════════════════════════╝"
    echo ""

    # vLLM auto-detects GPTQ / FP8 / FP16 from the HF repo config
    # No need for GGUF_FILENAME or VLLM_TOKENIZER
    docker run \
        --rm \
        -v "$(pwd)":/workdir \
        -w /workdir \
        --gpus all \
        --shm-size=16g \
        --entrypoint bash \
        -e LLM_MODEL="${LLM_MODEL}" \
        -e VLLM_MODEL="${LLM_MODEL}" \
        -e VLLM_TOKENIZER="" \
        -e ENABLE_THINKING="${ENABLE_THINKING}" \
        -e GGUF_FILENAME="" \
        -e NGPU=1 \
        -e MAX_MODEL_LEN="${MAX_MODEL_LEN}" \
        -e EVAL_DATASET="${EVAL_DATASET}" \
        -e PORT="${PORT}" \
        -e MODEL_TAG="${MODEL_TAG}" \
        -e PYTHONPATH="/workdir" \
        -e HF_HOME="/workdir/.cache/huggingface" \
        llm-wiki:latest \
        scripts/run_eval.sh \
        2>&1 | tee "logs/eval_${MODEL_TAG}_${EVAL_DATASET}.log"

    echo ""
    echo ">>> (${EVAL_DATASET}) complete!"
    echo "    Log:     logs/eval_${MODEL_TAG}_${EVAL_DATASET}.log"
}

# ── Model functions ──
# $DATASET is read from the second CLI argument
run_27b() {
    echo ">>> Qwen3.5-27B..."
    run_model \
        "Qwen/Qwen3.5-27B" \
        "${DATASET}" \
        "${ENABLE_THINKING}" \
        32768 \
        8000 
}

run_122b_gptq() {
    echo ">>> Qwen3.5-122B-A10B-GPTQ-Int4..."
    run_model \
        "Qwen/Qwen3.5-122B-A10B-GPTQ-Int4" \
        "${DATASET}" \
        "${ENABLE_THINKING}" \
        32768 \
        8000  
}

run_35b_fp8() {
    echo ">>> Qwen3.5-35B-A3B-FP8..."
    run_model \
        "Qwen/Qwen3.5-35B-A3B-FP8" \
        "${DATASET}" \
        "${ENABLE_THINKING}" \
        32768 \
        8000 
}

# ── Main ──
WHICH="${1:-all}"
DATASET="${2:-all}"  # squad, multihop, or all
ENABLE_THINKING="${3:-false}"   # optional "thinking" argument for SQuAD runs

case "${WHICH}" in
    1)
        run_27b
        ;;
    2)
        run_122b_gptq
        ;;
    3)
        run_35b_fp8
        ;;
    all)
        echo "═══════════════════════════════════════════════════════"
        echo "  Running 3 models sequentially (with cache cleanup)"
        echo "  Dataset: ${DATASET}"
        echo "═══════════════════════════════════════════════════════"
        echo ""
        run_27b
        cleanup_model_cache
        run_122b_gptq
        cleanup_model_cache
        run_35b_fp8
        cleanup_model_cache
        echo ""
        echo "═══════════════════════════════════════════════════════"
        echo "  All 3 models complete! Results:"
        echo "═══════════════════════════════════════════════════════"
        ls -lh outputs/*results*.json 2>/dev/null || echo "  (check outputs/ folder)"
        ;;
    *)
        echo "Usage: $0 [1|2|3|all] [squad|multihop|all] [thinking]"
        echo "    Model:   1=27B  2=122B-GPTQ  3=35B-FP8  all=sequential"
        echo "    Dataset: squad, multihop, or all"
        echo "    Thinking mode: ${ENABLE_THINKING}"
        exit 1
        ;;
esac
