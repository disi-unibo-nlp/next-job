#!/bin/bash
# ═══════════════════════════════════════════════════════
#  Run evaluation locally on Mac with MLX
#
#  Usage:
#    ./scripts/run_mlx_local.sh
#
#  All parameters come from .env at the repo root:
#    DATA_DIR         — dataset directory (e.g. data/squad_data)
#    LLM_MODEL        — MLX model repo (e.g. mlx-community/Qwen3.5-9B-MLX-4bit)
#    LLM_PORT         — MLX server port
#    ENABLE_THINKING  — "true" / "false"
#
#  Prerequisites:
#    pip install mlx-lm pymilvus[milvus_lite] FlagEmbedding \
#        rouge-score bert-score openai tqdm
#
#  chunks_with_embeddings.json must already exist.
# ═══════════════════════════════════════════════════════
set -e
cd "$(dirname "$0")/.."

# ── Load .env (export every variable defined there) ──
if [ ! -f .env ]; then
    echo "ERROR: .env not found at $(pwd)/.env"
    exit 1
fi
set -a
source .env
set +a

# ── Validate required vars ──
: "${DATA_DIR:?ERROR: DATA_DIR not set in .env}"
: "${LLM_MODEL:?ERROR: LLM_MODEL not set in .env}"
: "${LLM_PORT:?ERROR: LLM_PORT not set in .env}"
: "${ENABLE_THINKING:?ERROR: ENABLE_THINKING not set in .env}"
: "${MODEL_TAG:?ERROR: MODEL_TAG not set in .env}"

mkdir -p logs outputs

echo "╔══════════════════════════════════════════════╗"
echo "║  LLM Wiki — MLX Local Evaluation             ║"
echo "╠══════════════════════════════════════════════╣"
echo "║  DATA_DIR:        ${DATA_DIR}"
echo "║  LLM_MODEL:       ${LLM_MODEL} (${MODEL_TAG})"
echo "║  LLM_PORT:        ${LLM_PORT}"
echo "║  ENABLE_THINKING: ${ENABLE_THINKING}"
echo "╚══════════════════════════════════════════════╝"

# ── Start MLX server ──
start_mlx() {
    echo ">>> Starting MLX server: ${LLM_MODEL}"
    mlx_lm.server \
        --model "${LLM_MODEL}" \
        --port "${LLM_PORT}" \
        --prompt-cache-size 0 \
        > logs/mlx_server.log 2>&1 &
    MLX_PID=$!
    echo "    PID: ${MLX_PID}"

    echo "    Waiting for server..."
    for i in $(seq 1 60); do
        if curl -s http://localhost:${LLM_PORT}/v1/models > /dev/null 2>&1; then
            echo "    MLX server ready! (took ~${i}s)"
            return 0
        fi
        if ! kill -0 $MLX_PID 2>/dev/null; then
            echo "    ERROR: MLX server died. Log:"
            tail -20 logs/mlx_server.log
            exit 1
        fi
        sleep 1
    done
    echo "    ERROR: MLX server did not start in 60s"
    tail -20 logs/mlx_server.log
    kill $MLX_PID 2>/dev/null
    exit 1
}

stop_mlx() {
    if [ -n "$MLX_PID" ] && kill -0 $MLX_PID 2>/dev/null; then
        echo ">>> Stopping MLX server (PID ${MLX_PID})..."
        kill $MLX_PID 2>/dev/null
        wait $MLX_PID 2>/dev/null || true
    fi
}
trap stop_mlx EXIT

# ── Pipeline ──
start_mlx

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  Dataset: ${DATA_DIR}"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Wiki evaluate ──
WIKI_PATH="${DATA_DIR}/wiki"
# if [ ! -d "${WIKI_PATH}" ]; then
#     echo "    WARNING: ${WIKI_PATH} not found. Skipping wiki evaluation."
# else
#     echo ">>> [Wiki] Running evaluation..."
#     python -m src.wiki.evaluate --debug \
#         2>&1 | tee "logs/eval_${MODEL_TAG}_wiki.log"
# fi

# ── RAG pipeline ──
echo ""
echo ">>> [RAG] Inserting chunks into Milvus..."
python -m src.traditional.insert_milvus

echo ">>> [RAG] Running evaluation..."
python -m src.traditional.rag_evaluate --debug \
    2>&1 | tee "logs/eval_${MODEL_TAG}_rag.log"

echo ""
echo "═══════════════════════════════════════════════════════"
echo "  All done! Results:"
echo "═══════════════════════════════════════════════════════"
ls -lh outputs/${MODEL_TAG}*.json 2>/dev/null || echo "  (check outputs/ folder)"
