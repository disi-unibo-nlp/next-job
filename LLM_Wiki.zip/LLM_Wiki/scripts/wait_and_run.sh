#!/bin/bash

# 设置你需要的最小空闲显存（单位：MB）。90GB = 90 * 1024 = 92160 MB
REQUIRED_MEM=92160

# 检查间隔时间（单位：秒）
SLEEP_TIME=600

# 你的实际运行命令（替换成你真正要跑的 docker 启动命令或 python 脚本）
# 例如: ./scripts/build.sh 或者 docker run ...
MY_COMMAND="./scripts/run_local.sh 3 all"

echo "开始监控 GPU 0... 需要空闲显存: ${REQUIRED_MEM} MB"

while true; do
    # 获取 GPU 0 的空闲显存大小（只提取数字）
    FREE_MEM=$(nvidia-smi -i 0 --query-gpu=memory.free --format=csv,noheader,nounits)
    
    if [ "$FREE_MEM" -ge "$REQUIRED_MEM" ]; then
        echo "[$(date)] 发现可用显存: ${FREE_MEM} MB! 准备发射 🚀"
        # 执行你的任务
        $MY_COMMAND
        # 任务启动后跳出循环，避免重复启动
        break
    else
        echo "[$(date)] 当前空闲: ${FREE_MEM} MB，同事还在跑，继续等待..."
        # 休息 60 秒后再查
        sleep $SLEEP_TIME
    fi
done